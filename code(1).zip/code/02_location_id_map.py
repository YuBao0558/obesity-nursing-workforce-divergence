"""
GBD location_id -> ISO-3166 alpha-3 映射。

GBD location_id 是跨语言稳定编码，用它对齐最可靠（中文/英文下载都能对上）。
仅收录"国家/地区"层级，排除地区汇总、SDI 分组、世界银行/WHO 分区等。
"""
import pandas as pd
import os

ROOT = os.path.dirname(os.path.abspath(__file__))

# GBD location_id -> ISO3（国家/地区层级）
LOC_ID_TO_ISO3 = {
    6: "CHN", 7: "PRK", 8: "TWN", 10: "KHM", 11: "IDN", 12: "LAO", 13: "MYS",
    14: "MDV", 15: "MMR", 16: "PHL", 17: "LKA", 18: "THA", 19: "TLS", 20: "VNM",
    22: "FJI", 23: "KIR", 24: "MHL", 25: "FSM", 26: "PNG", 27: "WSM", 28: "SLB",
    29: "TON", 30: "VUT", 33: "ARM", 34: "AZE", 35: "GEO", 36: "KAZ", 37: "KGZ",
    38: "MNG", 39: "TJK", 40: "TKM", 41: "UZB", 43: "ALB", 44: "BIH", 45: "BGR",
    46: "HRV", 47: "CZE", 48: "HUN", 49: "MKD", 50: "MNE", 51: "POL", 52: "ROU",
    53: "SRB", 54: "SVK", 55: "SVN", 57: "BLR", 58: "EST", 59: "LVA", 60: "LTU",
    61: "MDA", 62: "RUS", 63: "UKR", 66: "BRN", 67: "JPN", 68: "KOR", 69: "SGP",
    71: "AUS", 72: "NZL", 74: "AND", 75: "AUT", 76: "BEL", 77: "CYP", 78: "DNK",
    79: "FIN", 80: "FRA", 81: "DEU", 82: "GRC", 83: "ISL", 84: "IRL", 85: "ISR",
    86: "ITA", 87: "LUX", 88: "MLT", 89: "NLD", 90: "NOR", 91: "PRT", 92: "ESP",
    93: "SWE", 94: "CHE", 95: "GBR", 97: "ARG", 98: "CHL", 99: "URY", 101: "CAN",
    102: "USA", 105: "ATG", 106: "BHS", 107: "BRB", 108: "BLZ", 109: "CUB",
    110: "DMA", 111: "DOM", 112: "GRD", 113: "GUY", 114: "HTI", 115: "JAM",
    116: "LCA", 117: "VCT", 118: "SUR", 119: "TTO", 121: "BOL", 122: "ECU",
    123: "PER", 125: "COL", 126: "CRI", 127: "SLV", 128: "GTM", 129: "HND",
    130: "MEX", 131: "NIC", 132: "PAN", 133: "VEN", 135: "BRA", 136: "PRY",
    139: "DZA", 140: "BHR", 141: "EGY", 142: "IRN", 143: "IRQ", 144: "JOR",
    145: "KWT", 146: "LBN", 147: "LBY", 148: "MAR", 149: "PSE", 150: "OMN",
    151: "QAT", 152: "SAU", 153: "SYR", 154: "TUN", 155: "TUR", 156: "ARE",
    157: "YEM", 160: "AFG", 161: "BGD", 162: "BTN", 163: "IND", 164: "NPL",
    165: "PAK", 168: "AGO", 169: "CAF", 170: "COG", 171: "COD", 172: "GNQ",
    173: "GAB", 175: "BDI", 176: "COM", 177: "DJI", 178: "ERI", 179: "ETH",
    180: "KEN", 181: "MDG", 182: "MWI", 183: "MUS", 184: "MOZ", 185: "RWA",
    186: "SYC", 187: "SOM", 189: "TZA", 190: "UGA", 191: "ZMB", 193: "BWA",
    194: "LSO", 195: "NAM", 196: "ZAF", 197: "SWZ", 198: "ZWE", 200: "BEN",
    201: "BFA", 202: "CMR", 203: "CPV", 204: "TCD", 205: "CIV", 206: "GMB",
    207: "GHA", 208: "GIN", 209: "GNB", 210: "LBR", 211: "MLI", 212: "MRT",
    213: "NER", 214: "NGA", 215: "STP", 216: "SEN", 217: "SLE", 218: "TGO",
    298: "ASM", 305: "BMU", 320: "COK", 349: "GRL", 351: "GUM", 367: "MCO",
    369: "NRU", 374: "NIU", 376: "MNP", 380: "PLW", 385: "PRI", 393: "KNA",
    396: "SMR", 413: "TKL", 416: "TUV", 422: "VIR", 435: "SSD", 522: "SDN",
}


def map_loc_id(df, id_col="location_id"):
    """用 location_id 映射到 iso3，返回带 iso3 列的 df。"""
    df = df.copy()
    df["iso3"] = df[id_col].map(LOC_ID_TO_ISO3)
    unmapped = df[df["iso3"].isna()][id_col].unique()
    if len(unmapped):
        print(f"[loc_id] {len(unmapped)} 个 location_id 未映射（多为地区汇总/SDI分组，正常）:")
        for u in sorted(unmapped)[:40]:
            print(f"    - {u}")
    return df
