"""
合并稿 DEA 年份错配敏感性分析。

主分析：各国最近年护理密度 → HAQ 2019（产出导向 BCC-DEA）
SA-1：限定护理年在 2019±3 年（2016-2022）的子集重跑 DEA
SA-2（同年对齐）：对有 2019 年护理数据的子集，用 2019 年护理密度配 HAQ 2019 重跑 DEA
SA-3：时序稳定性已在 15_nurse_timeseries_cv.py 完成，此处引用其结论

输出：
  results/sensitivity_dea_comparison.csv   主分析 vs SA-1 vs SA-2 对比表
  results/sensitivity_dea_detail.csv       逐国效率得分（三个模型）
"""
import os
import sys
import numpy as np
import pandas as pd
from scipy.optimize import linprog
from scipy.stats import spearmanr

PARENT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESULTS = os.path.join(PARENT, "results")

# ---- World Bank 2023 收入分组（从 05_mechanism.py 复制）----
WB_INCOME = {
    "AFG": "Low", "ALB": "Upper middle", "DZA": "Lower middle", "AGO": "Lower middle",
    "ARG": "Upper middle", "ARM": "Upper middle", "AUS": "High", "AUT": "High",
    "AZE": "Upper middle", "BGD": "Lower middle", "BLR": "Upper middle", "BEL": "High",
    "BLZ": "Lower middle", "BEN": "Lower middle", "BTN": "Lower middle", "BOL": "Lower middle",
    "BIH": "Upper middle", "BWA": "Upper middle", "BRA": "Upper middle", "BGR": "Upper middle",
    "BFA": "Low", "BDI": "Low", "CPV": "Lower middle", "KHM": "Lower middle", "CMR": "Lower middle",
    "CAN": "High", "CAF": "Low", "TCD": "Low", "CHL": "High", "CHN": "Upper middle",
    "COL": "Upper middle", "COM": "Lower middle", "COD": "Low", "COG": "Lower middle",
    "CRI": "Upper middle", "CIV": "Lower middle", "HRV": "High", "CUB": "Upper middle",
    "CZE": "High", "DNK": "High", "DJI": "Lower middle", "DOM": "Upper middle", "ECU": "Upper middle",
    "EGY": "Lower middle", "SLV": "Upper middle", "GNQ": "Upper middle", "ERI": "Low",
    "EST": "High", "SWZ": "Lower middle", "ETH": "Low", "FJI": "Upper middle", "FIN": "High",
    "FRA": "High", "GAB": "Upper middle", "GMB": "Low", "GEO": "Upper middle", "DEU": "High",
    "GHA": "Lower middle", "GRC": "High", "GTM": "Upper middle", "GIN": "Lower middle",
    "GNB": "Low", "GUY": "Upper middle", "HTI": "Lower middle", "HND": "Lower middle",
    "HUN": "High", "ISL": "High", "IND": "Lower middle", "IDN": "Upper middle", "IRN": "Upper middle",
    "IRQ": "Upper middle", "IRL": "High", "ISR": "High", "ITA": "High", "JAM": "Upper middle",
    "JPN": "High", "JOR": "Upper middle", "KAZ": "Upper middle", "KEN": "Lower middle",
    "KIR": "Lower middle", "KWT": "High", "KGZ": "Lower middle", "LAO": "Lower middle",
    "LVA": "High", "LBN": "Upper middle", "LSO": "Lower middle", "LBR": "Low", "LBY": "Upper middle",
    "LTU": "High", "LUX": "High", "MDG": "Low", "MWI": "Low", "MYS": "Upper middle",
    "MDV": "Upper middle", "MLI": "Low", "MLT": "High", "MRT": "Lower middle", "MUS": "Upper middle",
    "MEX": "Upper middle", "FSM": "Lower middle", "MDA": "Upper middle", "MNG": "Lower middle",
    "MNE": "Upper middle", "MAR": "Lower middle", "MOZ": "Low", "MMR": "Lower middle",
    "NAM": "Upper middle", "NPL": "Lower middle", "NLD": "High", "NZL": "High", "NIC": "Lower middle",
    "NER": "Low", "NGA": "Lower middle", "MKD": "Upper middle", "NOR": "High", "OMN": "High",
    "PAK": "Lower middle", "PAN": "Upper middle", "PNG": "Lower middle", "PRY": "Upper middle",
    "PER": "Upper middle", "PHL": "Lower middle", "POL": "High", "PRT": "High", "QAT": "High",
    "ROU": "High", "RUS": "Upper middle", "RWA": "Low", "WSM": "Lower middle", "STP": "Lower middle",
    "SAU": "High", "SEN": "Lower middle", "SRB": "Upper middle", "SLE": "Low", "SGP": "High",
    "SVK": "High", "SVN": "High", "SLB": "Lower middle", "SOM": "Low", "ZAF": "Upper middle",
    "SSD": "Low", "ESP": "High", "LKA": "Lower middle", "SDN": "Low", "SUR": "Upper middle",
    "SWE": "High", "CHE": "High", "SYR": "Low", "TJK": "Lower middle", "TZA": "Lower middle",
    "THA": "Upper middle", "TLS": "Lower middle", "TGO": "Low", "TON": "Upper middle",
    "TTO": "High", "TUN": "Lower middle", "TUR": "Upper middle", "TKM": "Upper middle",
    "UGA": "Low", "UKR": "Lower middle", "ARE": "High", "GBR": "High", "USA": "High",
    "URY": "High", "UZB": "Lower middle", "VUT": "Lower middle", "VEN": "Upper middle",
    "VNM": "Lower middle", "YEM": "Low", "ZMB": "Low", "ZWE": "Lower middle",
}
INCOME_RANK = {"Low": 1, "Lower middle": 2, "Upper middle": 3, "High": 4}
INCOME_ORDER = ["Low", "Lower middle", "Upper middle", "High"]


def bcc_output_dea(inputs, outputs):
    """
    产出导向 BCC（VRS）DEA。

    对每个 DMU，最大化产出径向扩张比 φ。
    φ >= 1，φ = 1 表示在前沿上，φ > 1 表示需要产出扩张 φ 倍才达前沿。

    LP（对 DMU j0）：
      max  φ
      s.t. Σ_j λ_j * y_j  >= φ * y_{j0}     （产出约束）
           Σ_j λ_j * x_j  <= x_{j0}          （投入约束）
           Σ_j λ_j = 1                        （VRS 凸性）
           λ_j >= 0, φ free (>=0)

    转为 linprog 标准形 (min c'z  s.t. Aub z <= bub, Aeq z = beq)：
      z = [φ, λ_1, ..., λ_n]
      c = [-1, 0, ..., 0]                      （min -φ = max φ）

      Aub:
        产出: [-y0, y1, y2, ..., yn]  <= 0     （Σ λ y - φ y0 <= 0）
        投入: [ 0,  x1, x2, ..., xn ]  <= x0   （Σ λ x <= x0）

      Aeq:
        [0, 1, 1, ..., 1] = 1                  （Σ λ = 1）

      bounds: φ ∈ [0, None], λ_j ∈ [0, None]

    返回：效率得分数组（φ 值），≥ 1。
    """
    n = len(inputs)
    scores = np.ones(n)

    for j0 in range(n):
        x0 = inputs[j0]
        y0 = outputs[j0]

        # 变量数：1 (φ) + n (λ)
        n_var = 1 + n

        # 目标：min -φ
        c = np.zeros(n_var)
        c[0] = -1.0

        # 不等式约束 Aub z <= bub
        # 行1（产出约束 Σ λ_j y_j >= φ y_0  →  φ y_0 - Σ λ_j y_j <= 0）
        #   即 φ 的系数 = y_0，λ_j 的系数 = -y_j
        row_out = np.zeros(n_var)
        row_out[0] = y0
        row_out[1:] = -outputs

        # 行2（投入约束 Σ λ_j x_j <= x_0）
        #   φ 的系数 = 0，λ_j 的系数 = x_j
        row_in = np.zeros(n_var)
        row_in[1:] = inputs

        Aub = np.vstack([row_out, row_in])
        bub = np.array([0.0, x0])

        # 等式约束：Σ λ = 1
        Aeq = np.zeros((1, n_var))
        Aeq[0, 1:] = 1.0
        beq = np.array([1.0])

        # 边界
        bounds = [(0, None)] * n_var  # φ >= 0, λ >= 0

        res = linprog(c, A_ub=Aub, b_ub=bub, A_eq=Aeq, b_eq=beq,
                      bounds=bounds, method="highs")

        if res.success:
            phi = res.x[0]
            # 理论上 φ >= 1；数值误差可能略小于 1
            scores[j0] = max(phi, 1.0)
        else:
            # 如果 LP 不可行或无界，标记为 NaN
            scores[j0] = np.nan

    return scores


def bootstrap_spearman_ci(x, y, n_boot=2000, seed=42):
    """Bootstrap Spearman 相关系数 95% CI"""
    rng = np.random.default_rng(seed)
    x = np.asarray(x)
    y = np.asarray(y)
    n = len(x)
    boots = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, size=n)
        if len(np.unique(x[idx])) > 1 and len(np.unique(y[idx])) > 1:
            r, _ = spearmanr(x[idx], y[idx])
            if not np.isnan(r):
                boots.append(r)
    if len(boots) < 100:
        return np.nan, np.nan
    lo = np.percentile(boots, 2.5)
    hi = np.percentile(boots, 97.5)
    return lo, hi


def run_dea_and_stats(df, label):
    """对给定子集跑 DEA，计算效率得分、Spearman 相关、bootstrap CI、收入分组汇总"""
    df = df.dropna(subset=["nurse_per10k", "haq_2019", "income_group"]).copy()
    df = df[df["nurse_per10k"] > 0].copy()
    df = df[df["haq_2019"].notna()].copy()

    if len(df) < 10:
        print(f"  [{label}] 样本过小 (n={len(df)})，跳过")
        return None, None

    inputs = df["nurse_per10k"].values
    outputs = df["haq_2019"].values

    scores = bcc_output_dea(inputs, outputs)
    df["efficiency"] = scores

    # Spearman: 效率 vs 收入等级（效率越高=得分越大=越低效，预期与收入负相关）
    income_ranks = df["income_group"].map(INCOME_RANK).values
    rho, pval = spearmanr(scores, income_ranks)
    ci_lo, ci_hi = bootstrap_spearman_ci(scores, income_ranks)

    # 前沿国家数
    n_frontier = int((scores <= 1.001).sum())

    # 收入分组汇总
    grp = df.groupby("income_group")["efficiency"].agg(["median", "mean", "count"]).reindex(INCOME_ORDER)

    summary = {
        "model": label,
        "n_countries": len(df),
        "n_frontier": n_frontier,
        "median_efficiency": float(np.median(scores)),
        "mean_efficiency": float(np.mean(scores)),
        "spearman_rho": float(rho),
        "spearman_p": float(pval),
        "bootstrap_ci_lo": float(ci_lo),
        "bootstrap_ci_hi": float(ci_hi),
    }

    # 收入分组效率
    for ig in INCOME_ORDER:
        sub = grp.loc[ig]
        summary[f"{ig}_median"] = float(sub["median"]) if pd.notna(sub["median"]) else np.nan
        summary[f"{ig}_mean"] = float(sub["mean"]) if pd.notna(sub["mean"]) else np.nan
        summary[f"{ig}_n"] = int(sub["count"]) if pd.notna(sub["count"]) else 0

    print(f"\n  [{label}] n={len(df)}, 前沿={n_frontier}, "
          f"效率中位={np.median(scores):.3f}, "
          f"Spearman ρ={rho:.3f} (p={pval:.4f}), "
          f"95% CI=[{ci_lo:.3f}, {ci_hi:.3f}]")
    print(f"    收入分组效率中位数:")
    for ig in INCOME_ORDER:
        v = grp.loc[ig, "median"]
        n = grp.loc[ig, "count"]
        print(f"      {ig:16s}: {v:.3f} (n={int(n)})" if pd.notna(v) else f"      {ig:16s}: N/A")

    return summary, df[["iso3", "income_group", "nurse_per10k", "haq_2019", "efficiency"]]


def main():
    print("=" * 70)
    print("方向1 DEA 年份错配敏感性分析")
    print("=" * 70)

    # ---- 装载数据 ----
    haq = pd.read_csv(os.path.join(RESULTS, "haq_merge.csv"))
    # haq_merge.csv: iso3, haq_2019, nurse_per10k(最新年), daly_rate_end

    nurse_latest = pd.read_csv(os.path.join(RESULTS, "nurse_density_pure.csv"))
    # nurse_density_pure.csv: iso3, nurse_per10k, nurse_year_latest, who_region

    nurse_ts = pd.read_csv(os.path.join(RESULTS, "nurse_timeseries.csv"))
    # nurse_timeseries.csv: iso3, year, nurse_number, who_region, population, nurse_per10k

    # 合并收入分组
    haq["income_group"] = haq["iso3"].map(WB_INCOME)

    # 主分析用 haq_merge 的 nurse_per10k（最新年），补上年份信息
    main_df = haq.merge(
        nurse_latest[["iso3", "nurse_year_latest"]].rename(columns={"nurse_year_latest": "nurse_year"}),
        on="iso3", how="left"
    )
    main_df = main_df.rename(columns={"nurse_per10k": "nurse_per10k"})

    print(f"\n数据装载完成:")
    print(f"  haq_merge: {len(haq)} 国")
    print(f"  nurse_density_pure: {len(nurse_latest)} 国")
    print(f"  nurse_timeseries: {nurse_ts['iso3'].nunique()} 国, {len(nurse_ts)} 行")

    # ================================================================
    # 主分析：最新年护理密度 → HAQ 2019
    # ================================================================
    print("\n" + "=" * 70)
    print("主分析：各国最近年护理密度 → HAQ 2019")
    print("=" * 70)
    main_summary, main_detail = run_dea_and_stats(main_df, "Main (latest year)")

    # ================================================================
    # SA-1：限定护理年在 2019±3 年（2016-2022）
    # ================================================================
    print("\n" + "=" * 70)
    print("SA-1：限定护理年在 2019±3 年（2016-2022）")
    print("=" * 70)
    sa1_df = main_df[(main_df["nurse_year"] >= 2016) & (main_df["nurse_year"] <= 2022)].copy()
    print(f"  纳入国家数: {len(sa1_df)}")
    sa1_summary, sa1_detail = run_dea_and_stats(sa1_df, "SA-1 (2016-2022 window)")

    # ================================================================
    # SA-2（同年对齐）：用 2019 年护理密度配 HAQ 2019
    # ================================================================
    print("\n" + "=" * 70)
    print("SA-2（同年对齐）：用 2019 年护理密度配 HAQ 2019")
    print("=" * 70)

    # 从时间序列提取 2019 年护理密度
    nurse_2019 = nurse_ts[nurse_ts["year"] == 2019][["iso3", "nurse_per10k"]].copy()
    nurse_2019 = nurse_2019.rename(columns={"nurse_per10k": "nurse_per10k_2019"})
    nurse_2019["nurse_year"] = 2019

    sa2_df = haq[["iso3", "haq_2019", "income_group"]].merge(
        nurse_2019[["iso3", "nurse_per10k_2019", "nurse_year"]],
        on="iso3", how="inner"
    )
    sa2_df = sa2_df.rename(columns={"nurse_per10k_2019": "nurse_per10k"})
    print(f"  有 2019 年护理数据且匹配 HAQ 的国家数: {len(sa2_df)}")
    sa2_summary, sa2_detail = run_dea_and_stats(sa2_df, "SA-2 (2019 aligned)")

    # ================================================================
    # 汇总对比
    # ================================================================
    print("\n" + "=" * 70)
    print("汇总对比：主分析 vs SA-1 vs SA-2")
    print("=" * 70)

    summaries = []
    details = []
    for s, d, tag in [
        (main_summary, main_detail, "Main"),
        (sa1_summary, sa1_detail, "SA-1"),
        (sa2_summary, sa2_detail, "SA-2"),
    ]:
        if s is not None:
            summaries.append(s)
            if d is not None:
                d = d.copy()
                d["model"] = tag
                details.append(d)

    comp = pd.DataFrame(summaries)
    comp.to_csv(os.path.join(RESULTS, "sensitivity_dea_comparison.csv"), index=False)

    detail_all = pd.concat(details, ignore_index=True)
    detail_all.to_csv(os.path.join(RESULTS, "sensitivity_dea_detail.csv"), index=False)

    # 打印对比表
    print("\n| 模型 | n | 前沿数 | 效率中位 | Spearman ρ | p值 | 95% CI |")
    print("|------|---|--------|---------|-----------|-----|--------|")
    for _, row in comp.iterrows():
        ci = f"[{row['bootstrap_ci_lo']:.3f}, {row['bootstrap_ci_hi']:.3f}]"
        print(f"| {row['model']} | {row['n_countries']} | {row['n_frontier']} | "
              f"{row['median_efficiency']:.3f} | {row['spearman_rho']:.3f} | "
              f"{row['spearman_p']:.4f} | {ci} |")

    # 收入分组效率对比
    print("\n收入分组效率中位数对比:")
    print(f"{'收入组':<16} {'主分析':<12} {'SA-1':<12} {'SA-2(同年)':<12}")
    print("-" * 52)
    for ig in INCOME_ORDER:
        vals = []
        for s in summaries:
            v = s.get(f"{ig}_median", np.nan)
            n = s.get(f"{ig}_n", 0)
            vals.append(f"{v:.3f}(n={n})" if pd.notna(v) and n > 0 else "-")
        print(f"{ig:<16} {vals[0]:<12} {vals[1]:<12} {vals[2]:<12}")

    # 核心结论判断
    print("\n" + "=" * 70)
    print("结论判断")
    print("=" * 70)
    main_rho = main_summary["spearman_rho"]
    main_p = main_summary["spearman_p"]
    main_ci = (main_summary["bootstrap_ci_lo"], main_summary["bootstrap_ci_hi"])

    all_stable = True
    for s, tag in [(sa1_summary, "SA-1"), (sa2_summary, "SA-2")]:
        if s is None:
            continue
        rho_s = s["spearman_rho"]
        p_s = s["spearman_p"]
        ci_s = (s["bootstrap_ci_lo"], s["bootstrap_ci_hi"])

        # 方向一致：同号
        same_sign = (main_rho * rho_s > 0)
        # 显著性一致：都显著或都不显著
        both_sig = (main_p < 0.05) and (p_s < 0.05)
        both_insig = (main_p >= 0.05) and (p_s >= 0.05)
        sig_consistent = both_sig or both_insig
        # CI 重叠
        ci_overlap = not (main_ci[1] < ci_s[0] or main_ci[0] > ci_s[1])

        status = "✓ 稳健" if (same_sign and sig_consistent) else "△ 部分偏移"
        print(f"  {tag}: ρ={rho_s:.3f} vs 主分析 ρ={main_rho:.3f} → {status} "
              f"(方向{'一致' if same_sign else '不一致'}, "
              f"显著性{'一致' if sig_consistent else '不一致'}, "
              f"CI{'重叠' if ci_overlap else '不重叠'})")

        if not (same_sign and sig_consistent):
            all_stable = False

    if all_stable:
        print("\n  ✓ 所有敏感性分析均支持主分析的核心结论：")
        print("    效率得分与收入等级的负相关关系在年份错配处理后方向和显著性不变。")
        print("    → 年份错配未系统扭曲核心发现。")
    else:
        print("\n  △ 部分敏感性分析出现偏移，需在 Limitations 中详细讨论。")

    print(f"\n输出文件:")
    print(f"  results/sensitivity_dea_comparison.csv  (三模型对比汇总)")
    print(f"  results/sensitivity_dea_detail.csv     (逐国效率得分)")


if __name__ == "__main__":
    main()
