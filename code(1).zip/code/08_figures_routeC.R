#!/usr/bin/env Rscript
# ============================================================
# 路线C 合并稿图表生成脚本
# 生成6张SCI论文图表：
#   Fig 1: OKC五面板散点+拟合（1990-2023）
#   Fig 2: 负担vs护理人力的收入维度背离箱线图
#   Fig 3: 单投入vs多投入DEA效率对比
#   Fig 4: 全球DEA效率世界地图
#   Fig 5: Malmquist指数EC-TC分解
#   Fig 6: Simar-Wilson GDP系数时变森林图
# ============================================================
suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(patchwork)
  library(scales)
  library(ggrepel)
  library(viridis)
})

base <- "/Users/yubao/DOCTOR/1_博课题/8_writing/open data"
figdir <- file.path(base, "results", "figures")
dir.create(figdir, showWarnings = FALSE, recursive = TRUE)

# 统一配色
COL_BLUE   <- "#2c5f8d"
COL_RED    <- "#c0392b"
COL_GREEN  <- "#27ae60"
COL_ORANGE <- "#e67e22"
COL_GREY   <- "#7f8c8d"
COL_INCOME <- c("Low" = "#e74c3c", "Lower-middle" = "#e67e22",
                "Upper-middle" = "#f1c40f", "High" = "#2c5f8d")

theme_sci <- function(base_size = 11) {
  theme_bw(base_size = base_size) +
  theme(
    panel.grid.minor = element_blank(),
    panel.grid.major = element_blank(),
    panel.border = element_rect(linewidth = 0.5, color = "grey40", fill = NA),
    axis.line = element_line(linewidth = 0.4, color = "grey40"),
    axis.ticks = element_line(linewidth = 0.3, color = "grey50"),
    legend.position = "bottom",
    legend.title = element_text(size = 9, face = "bold"),
    legend.text = element_text(size = 8),
    strip.background = element_rect(fill = "grey92", color = "grey60"),
    strip.text = element_text(size = 10, face = "bold"),
    plot.title = element_text(size = 11, face = "bold", hjust = 0),
    plot.tag = element_text(size = 14, face = "bold")
  )
}

save_fig <- function(p, name, w = 7, h = 5) {
  ggsave(file.path(figdir, paste0(name, ".pdf")), p, width = w, height = h,
         device = grDevices::pdf, useDingbats = FALSE)
  ggsave(file.path(figdir, paste0(name, ".png")), p, width = w, height = h,
         dpi = 600)
  cat(sprintf("  %s 已生成\n", name))
}

# ============================================================
# Fig 1: OKC五面板散点+二次拟合（1990-2023）
# ============================================================
cat("\n[Fig 1] OKC五面板...\n")

panel <- read.csv(file.path(base, "results", "panel_master_routeC.csv"))
okc_res <- read.csv(file.path(base, "results", "okc_pooled_by_year.csv"))

panel$year_f <- factor(panel$year, levels = c(1990, 2000, 2010, 2020, 2023))

# 为每个年份计算拐点的x值（ln GNI）
turning_points <- okc_res %>%
  mutate(tp_ln_gni = -beta_gni / (2 * beta_gni2),
         tp_gni = turning_point_gni) %>%
  select(year, tp_ln_gni, tp_gni)

p1_list <- lapply(c(1990, 2000, 2010, 2020, 2023), function(yr) {
  d <- panel %>% filter(year == yr, !is.na(ln_gni), !is.na(ln_bmi_daly))
  tp <- turning_points %>% filter(year == yr)
  ggplot(d, aes(x = ln_gni, y = ln_bmi_daly)) +
    geom_point(alpha = 0.5, size = 1.2, color = COL_BLUE) +
    geom_smooth(method = "lm", formula = y ~ poly(x, 2),
                se = TRUE, color = COL_RED, linewidth = 0.7, fill = alpha(COL_RED, 0.15)) +
    geom_vline(xintercept = tp$tp_ln_gni, linetype = "dashed",
               color = COL_ORANGE, linewidth = 0.5) +
    annotate("text", x = tp$tp_ln_gni, y = max(d$ln_bmi_daly, na.rm = TRUE) - 0.8,
             label = sprintf("TP: $%s", format(round(tp$tp_gni), big.mark = ",")),
             size = 2.8, color = COL_ORANGE, hjust = -0.05, vjust = 0) +
    labs(title = sprintf("%d (n=%d, R2=%.2f)", yr, nrow(d),
                         okc_res$r2[okc_res$year == yr])) +
    labs(x = "ln(GNI per capita)", y = "ln(DALY rate)") +
    theme_sci(9) +
    theme(plot.title = element_text(size = 10, face = "bold"),
          plot.margin = margin(8, 12, 8, 8))
})

p1 <- wrap_plots(p1_list, nrow = 1) +
  plot_annotation(title = "Figure 1. Obesity Kuznets Curve across five time points (1990-2023)",
                  tag_levels = "a",
                  theme = theme(plot.title = element_text(size = 12, face = "bold", hjust = 0)))

save_fig(p1, "fig1_okc_panel", w = 14, h = 3.2)

# ============================================================
# Fig 2: 负担vs护理人力的收入维度背离
# ============================================================
cat("\n[Fig 2] 负担vs人力背离...\n")

d2023 <- panel %>%
  filter(year == 2023, !is.na(income_group), income_group != "",
         !is.na(bmi_daly_rate), !is.na(nurse_per10k)) %>%
  mutate(income_group = factor(income_group,
          levels = c("Low", "Lower-middle", "Upper-middle", "High"),
          labels = c("Low", "Lower-middle", "Upper-middle", "High"))) %>%
  filter(!is.na(income_group))

# 左图：负担率箱线图
p2a <- ggplot(d2023 %>% filter(!is.na(bmi_daly_rate)),
              aes(x = income_group, y = bmi_daly_rate, fill = income_group)) +
  geom_boxplot(alpha = 0.7, outlier.size = 0.8, linewidth = 0.4) +
  scale_fill_manual(values = COL_INCOME) +
  stat_summary(fun = median, geom = "crossbar", width = 0.5, color = "black", linewidth = 0.3) +
  labs(x = "", y = "High-BMI attributable DALY rate\n(per 100,000, 2023)",
       tag = "a",
       subtitle = expression(paste(rho, "(GNI vs burden) = -0.08 (p = 0.30)"))) +
  theme_sci(10) +
  theme(legend.position = "none",
        axis.text.x = element_text(angle = 20, hjust = 1, size = 9))

# 右图：护理密度箱线图
p2b <- ggplot(d2023 %>% filter(!is.na(nurse_per10k)),
              aes(x = income_group, y = nurse_per10k, fill = income_group)) +
  geom_boxplot(alpha = 0.7, outlier.size = 0.8, linewidth = 0.4) +
  scale_fill_manual(values = COL_INCOME) +
  scale_y_log10(labels = comma) +
  stat_summary(fun = median, geom = "crossbar", width = 0.5, color = "black", linewidth = 0.3) +
  labs(x = "World Bank income group",
       y = "Nursing density (per 10,000, log scale)",
       tag = "b",
       subtitle = expression(paste(rho, "(GNI vs nurse) = 0.84 (p < 0.001)"))) +
  theme_sci(10) +
  theme(legend.position = "none",
        axis.text.x = element_text(angle = 20, hjust = 1, size = 9))

p2 <- (p2a | p2b) +
  plot_annotation(title = "Figure 2. Divergence of obesity burden and nursing workforce by income group (2023)",
                  theme = theme(plot.title = element_text(size = 12, face = "bold", hjust = 0)))

save_fig(p2, "fig2_burden_nurse_mismatch", w = 11, h = 5)

# ============================================================
# Fig 3: 单投入vs多投入DEA效率对比
# ============================================================
cat("\n[Fig 3] 单投入vs多投入DEA对比...\n")

dea_multi <- read.csv(file.path(base, "results", "dea_multi_input_results.csv"))
dea_single <- read.csv(file.path(base, "results", "sensitivity_dea_detail.csv"))

# 单投入（Main模型，2023年）
single_2023 <- dea_single %>%
  filter(model == "Main")

# 补GNI（重命名避免冲突）
gni_ref <- panel %>% filter(year == 2023) %>% select(iso3, gni_pc_val = gni_pc, ln_gni_val = ln_gni)
single_2023 <- single_2023 %>%
  left_join(gni_ref, by = "iso3") %>%
  filter(!is.na(ln_gni_val), !is.na(efficiency))

# 多投入（2023年）
multi_2023 <- dea_multi %>%
  filter(analysis_year == 2023, !is.na(efficiency_phi), !is.na(ln_gni)) %>%
  rename(efficiency = efficiency_phi)

# 计算Spearman
rho_single <- cor.test(single_2023$ln_gni_val, single_2023$efficiency, method = "spearman")
rho_multi  <- cor.test(multi_2023$ln_gni, multi_2023$efficiency, method = "spearman")

p3a <- ggplot(single_2023, aes(x = ln_gni_val, y = efficiency)) +
  geom_point(alpha = 0.5, size = 1.5, color = COL_BLUE) +
  geom_smooth(method = "lm", se = TRUE, color = COL_RED, linewidth = 0.6,
              fill = alpha(COL_RED, 0.15)) +
  geom_hline(yintercept = 1, linetype = "dashed", color = "grey50", linewidth = 0.4) +
  labs(x = "ln(GNI per capita)", y = "Efficiency (phi)",
       title = "Single-input DEA (nurse -> HAQ)",
       subtitle = sprintf("rho = %.3f, p < 0.001", rho_single$estimate),
       tag = "a") +
  theme_sci(10)

p3b <- ggplot(multi_2023, aes(x = ln_gni, y = efficiency)) +
  geom_jitter(alpha = 0.5, size = 1.5, color = COL_GREEN, width = 0, height = 0.003) +
  geom_smooth(method = "lm", se = TRUE, color = COL_ORANGE, linewidth = 0.6,
              fill = alpha(COL_ORANGE, 0.15)) +
  geom_hline(yintercept = 1, linetype = "dashed", color = "grey50", linewidth = 0.4) +
  scale_y_continuous(limits = c(0.98, max(multi_2023$efficiency) * 1.08)) +
  labs(x = "ln(GNI per capita)", y = "Efficiency (phi)",
       title = "Multi-input DEA (nurse + doctor + bed -> HAQ + UHC)",
       subtitle = sprintf("rho = %.3f, p = %.3f", rho_multi$estimate, rho_multi$p.value),
       tag = "b") +
  theme_sci(10)

p3 <- (p3a | p3b) +
  plot_annotation(title = "Figure 3. Single-input vs multi-input DEA efficiency vs income (2023)",
                  theme = theme(plot.title = element_text(size = 12, face = "bold", hjust = 0)))

save_fig(p3, "fig3_dea_single_vs_multi", w = 12, h = 5)

# ============================================================
# Fig 5: Malmquist指数EC-TC分解
# ============================================================
cat("\n[Fig 5] Malmquist分解...\n")

malm <- read.csv(file.path(base, "results", "malmquist_all.csv"))
malm <- malm %>% filter(!is.na(ec), !is.na(tc), !is.na(malmquist))
malm$period <- factor(ifelse(malm$year_t1 == 2020, "2010->2020", "2020->2023"),
                      levels = c("2010->2020", "2020->2023"))

p4 <- ggplot(malm, aes(x = ec, y = tc, color = period)) +
  geom_point(alpha = 0.6, size = 1.8) +
  geom_hline(yintercept = 1, linetype = "dashed", color = "grey50", linewidth = 0.4) +
  geom_vline(xintercept = 1, linetype = "dashed", color = "grey50", linewidth = 0.4) +
  annotate("rect", xmin = -Inf, xmax = 1, ymin = -Inf, ymax = 1,
           fill = alpha(COL_RED, 0.06)) +
  annotate("rect", xmin = 1, xmax = Inf, ymin = 1, ymax = Inf,
           fill = alpha(COL_GREEN, 0.06)) +
  annotate("text", x = 0.7, y = 0.92, label = "Decline", size = 3, color = COL_RED, alpha = 0.6) +
  annotate("text", x = 1.15, y = 1.08, label = "Improvement", size = 3, color = COL_GREEN, alpha = 0.6) +
  scale_color_manual(values = c("2010->2020" = COL_BLUE, "2020->2023" = COL_ORANGE)) +
  labs(x = "Efficiency catch-up (EC)\n(< 1 = falling behind frontier)",
       y = "Technical change (TC)\n(< 1 = frontier contracting)",
       color = "Period",
       title = "Figure 5. Malmquist index decomposition") +
  coord_cartesian(xlim = c(0.6, 1.5), ylim = c(0.85, 1.15)) +
  theme_sci(10)

save_fig(p4, "fig5_malmquist_decomposition", w = 7, h = 6)

# ============================================================
# Fig 6: Simar-Wilson GDP系数时变森林图
# ============================================================
cat("\n[Fig 6] Simar-Wilson森林图...\n")

sw <- read.csv(file.path(base, "results", "simar_wilson_second_stage.csv"))

# 解析CI
sw$ci_low  <- as.numeric(gsub("\\[|\\]| ", "", strsplit(as.character(sw$ci_ln_gdp), ",")[[1]][1]))
sw$ci_high <- as.numeric(gsub("\\[|\\]| ", "", strsplit(as.character(sw$ci_ln_gdp), ",")[[1]][2]))
# 逐行解析
sw$ci_low <- sapply(sw$ci_ln_gdp, function(x) {
  as.numeric(gsub("[^0-9.\\-]", "", strsplit(as.character(x), ",")[[1]][1]))
})
sw$ci_high <- sapply(sw$ci_ln_gdp, function(x) {
  as.numeric(gsub("[^0-9.\\-]", "", strsplit(as.character(x), ",")[[1]][2]))
})
sw$year_f <- factor(sw$year)
sw$label <- sprintf("2010\n(n=%d)", sw$n[1])
sw$label <- ifelse(sw$year == 2010, sprintf("2010 (n=%d)", sw$n[1]),
            ifelse(sw$year == 2020, sprintf("2020 (n=%d)", sw$n[2]),
                                     sprintf("2023 (n=%d)", sw$n[3])))

p5 <- ggplot(sw, aes(x = beta_ln_gdp, y = factor(year, levels = c(2023, 2020, 2010)),
                     color = factor(year))) +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey50", linewidth = 0.4) +
  geom_errorbarh(aes(xmin = ci_low, xmax = ci_high), height = 0.15, linewidth = 0.8) +
  geom_point(size = 4) +
  scale_color_manual(values = c("2010" = COL_BLUE, "2020" = COL_ORANGE, "2023" = COL_GREEN)) +
  labs(x = "beta(ln GDP) - Simar-Wilson bootstrap regression",
       y = "Year",
       color = "Year",
        title = "Figure 6. GDP effect on conversion efficiency over time\n(Simar-Wilson second-stage, 1000 bootstrap)") +
  coord_cartesian(xlim = c(-0.01, 0.05)) +
  theme_sci(10) +
  theme(legend.position = "none",
        plot.title = element_text(size = 11, face = "bold"))

# 文字放在图右侧（不叠在点上）
sw_sorted <- sw[order(sw$year, decreasing = TRUE), ]
p5 <- p5 +
  annotate("text", x = 0.036, y = 3,
           label = sprintf("beta = %.4f\n95%% CI [%.4f, %.4f]\nR2 = %.3f",
                           sw_sorted$beta_ln_gdp[1], sw_sorted$ci_low[1], sw_sorted$ci_high[1], sw_sorted$r2[1]),
           hjust = 0, vjust = 1, size = 2.8, color = COL_GREEN) +
  annotate("text", x = 0.036, y = 2,
           label = sprintf("beta = %.4f\n95%% CI [%.4f, %.4f]\nR2 = %.3f",
                           sw_sorted$beta_ln_gdp[2], sw_sorted$ci_low[2], sw_sorted$ci_high[2], sw_sorted$r2[2]),
           hjust = 0, vjust = 1, size = 2.8, color = COL_ORANGE) +
  annotate("text", x = 0.036, y = 1,
           label = sprintf("beta = %.4f\n95%% CI [%.4f, %.4f]\nR2 = %.3f",
                           sw_sorted$beta_ln_gdp[3], sw_sorted$ci_low[3], sw_sorted$ci_high[3], sw_sorted$r2[3]),
           hjust = 0, vjust = 1, size = 2.8, color = COL_BLUE)

save_fig(p5, "fig6_simar_wilson_forest", w = 9, h = 4.5)

# ============================================================
# Fig 4: 全球DEA效率世界地图
# ============================================================
cat("\n[Fig 4] 全球DEA效率地图...\n")

suppressPackageStartupMessages(library(sf))

# 获取世界地图数据
world <- sf::st_as_sf(maps::map("world", plot = FALSE, fill = TRUE))
# maps包返回的region名称需要映射到ISO3
# 用countrycode或手动映射
iso3_map <- data.frame(
  region = c("Afghanistan","Angola","Albania","United Arab Emirates","Argentina","Armenia",
    "Antigua and Barbuda","Australia","Austria","Azerbaijan","Burundi","Belgium","Benin",
    "Burkina Faso","Bangladesh","Bulgaria","Bahamas","Bosnia and Herzegovina","Belarus",
    "Belize","Bermuda","Bolivia","Brazil","Barbados","Brunei","Bhutan","Botswana",
    "Central African Republic","Canada","Switzerland","Chile","China","Ivory Coast",
    "Cameroon","Democratic Republic of the Congo","Republic of Congo","Colombia","Comoros",
    "Cape Verde","Costa Rica","Cuba","Cyprus","Czech Republic","Germany","Djibouti",
    "Dominica","Dominican Republic","Denmark","Algeria","Ecuador","Egypt","Eritrea","Spain",
    "Estonia","Ethiopia","Finland","Fiji","France","Gabon","UK","Georgia",
    "Ghana","Guinea","Gambia","Guinea Bissau","Equatorial Guinea","Greece","Grenada",
    "Greenland","Guatemala","Guyana","Honduras","Croatia","Haiti","Hungary","Indonesia",
    "India","Ireland","Iran","Iraq","Iceland","Israel","Italy","Jamaica","Jordan",
    "Japan","Kazakhstan","Kenya","Kyrgyzstan","Cambodia","Kiribati","South Korea",
    "Kuwait","Laos","Lebanon","Liberia","Libya","Saint Lucia","Liechtenstein","Sri Lanka",
    "Lesotho","Lithuania","Luxembourg","Latvia","Macedonia","Madagascar","Mexico",
    "Moldova","Maldives","Mali","Malta","Mauritania","Mauritius","Morocco","Mongolia",
    "Mozambique","Myanmar","Namibia","Niger","Nigeria","Nicaragua","Netherlands",
    "Norway","Nepal","Nauru","New Zealand","Oman","Pakistan","Panama","Peru",
    "Philippines","Palau","Papua New Guinea","Poland","Portugal","North Korea",
    "Qatar","Romania","Russia","Rwanda","Saudi Arabia","Sudan","Senegal","Sierra Leone",
    "El Salvador","Somalia","San Marino","Sao Tome and Principe","Suriname","Slovakia",
    "Slovenia","Sweden","Swaziland","Seychelles","Syria","Chad","Togo","Thailand",
    "Tajikistan","Turkmenistan","Tonga","Trinidad and Tobago","Tunisia","Turkey",
    "Tuvalu","Tanzania","Uganda","Ukraine","Uruguay","USA","Uzbekistan",
    "Venezuela","Vietnam","Vanuatu","Yemen","South Africa","Zambia","Zimbabwe",
    "Eswatini","Czechia","North Macedonia","Republic of Korea","Russia",
    "South Sudan","Timor-Leste","Solomon Islands"),
  iso3 = c("AFG","AGO","ALB","ARE","ARG","ARM","ATG","AUS","AUT","AZE","BDI","BEL","BEN",
    "BFA","BGD","BGR","BHS","BIH","BLR","BLZ","BMU","BOL","BRA","BRB","BRN","BTN","BWA",
    "CAF","CAN","CHE","CHL","CHN","CIV","CMR","COD","COG","COL","COM","CPV","CRI","CUB",
    "CYP","CZE","DEU","DJI","DMA","DOM","DNK","DZA","ECU","EGY","ERI","ESP","EST","ETH",
    "FIN","FJI","FRA","GAB","GBR","GEO","GHA","GIN","GMB","GNB","GNQ","GRC","GRD","GRL",
    "GTM","GUY","HND","HRV","HTI","HUN","IDN","IND","IRL","IRN","IRQ","ISL","ISR","ITA",
    "JAM","JOR","JPN","KAZ","KEN","KGZ","KHM","KIR","KOR","KWT","LAO","LBN","LBR","LBY",
    "LCA","LIE","LKA","LSO","LTU","LUX","LVA","MKD","MDG","MEX","MDA","MDV","MLI","MLT",
    "MRT","MUS","MAR","MNG","MOZ","MMR","NAM","NER","NGA","NIC","NLD","NOR","NPL","NRU",
    "NZL","OMN","PAK","PAN","PER","PHL","PLW","PNG","POL","PRT","PRK","QAT","ROU","RUS",
    "RWA","SAU","SDN","SEN","SLE","SLV","SOM","SMR","STP","SUR","SVK","SVN","SWE","SWZ",
    "SYC","SYR","TCD","TGO","THA","TJK","TKM","TON","TTO","TUN","TUR","TUV","TZA","UGA",
    "UKR","URY","USA","UZB","VEN","VNM","VUT","YEM","ZAF","ZMB","ZWE",
    "SWZ","CZE","MKD","KOR","RUS","SSD","TLS","SLB")
)

world$iso3 <- iso3_map$iso3[match(world$ID, iso3_map$region)]

# 打印匹配情况用于调试
cat("  地图region数:", length(unique(world$ID)), "\n")
cat("  匹配到ISO3的:", sum(!is.na(world$iso3)), "\n")

# 2023年多投入DEA效率
map_data <- dea_multi %>%
  filter(analysis_year == 2023, !is.na(efficiency_phi)) %>%
  select(iso3, efficiency_phi) %>%
  rename(efficiency = efficiency_phi)

world_join <- world %>%
  left_join(map_data, by = "iso3")

cat("  地图上有效率数据的国家:", sum(!is.na(world_join$efficiency)), "\n")

# 效率分组（1=完全有效，>1=有损失）
world_join$eff_cat <- cut(world_join$efficiency,
                          breaks = c(0.9, 1.001, 1.1, 1.3, Inf),
                          labels = c("<= 1.0 (Efficient)", "1.0-1.1", "1.1-1.3", "> 1.3"),
                          include.lowest = TRUE)

p6 <- ggplot(world_join) +
  geom_sf(aes(fill = eff_cat), color = "grey70", linewidth = 0.08) +
  scale_fill_manual(values = c("<= 1.0 (Efficient)" = "#1a9850",
                               "1.0-1.1" = "#a6d96a",
                               "1.1-1.3" = "#fdae61",
                               "> 1.3" = "#d73027"),
                    na.value = "grey90",
                    name = "Efficiency (phi)",
                    drop = FALSE) +
  labs(title = "Figure 4. Global distribution of multi-input DEA conversion efficiency (2023)",
       subtitle = "Nurse + doctor + bed -> HAQ + UHC. phi >= 1; higher = lower output for same input") +
  coord_sf(xlim = c(-180, 180), ylim = c(-60, 85)) +
  theme_minimal(base_size = 10) +
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    axis.text = element_blank(),
    axis.ticks = element_blank(),
    axis.title = element_blank(),
    legend.position = "bottom",
    legend.key.size = unit(0.5, "cm"),
    legend.text = element_text(size = 8),
    legend.title = element_text(size = 9, face = "bold"),
    plot.title = element_text(size = 11, face = "bold", hjust = 0),
    plot.subtitle = element_text(size = 9, color = "grey30", hjust = 0),
    panel.background = element_rect(fill = "white", color = NA)
  )

save_fig(p6, "fig4_world_efficiency_map", w = 12, h = 6)

cat("\n============================================\n")
cat("全部6张图已生成至 results/figures/\n")
cat("============================================\n")
