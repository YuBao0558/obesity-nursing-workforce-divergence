"""
合并稿数据下载脚本
从 WHO GHO API 和 World Bank API 下载主分析所需指标：
1. 医生人数 (WHO GHO HWF_0002) - 多年份
2. 医生密度 (WHO GHO HWF_0001) - 每万人
3. 医院床位 (WHO GHO WHS6_102) - 每万人
4. UHC服务覆盖指数 (WHO GHO UHC_INDEX_REPORTED) - SDG 3.8.1
5. GNI人均 (World Bank NY.GNP.PCAP.CD) 1990-2023
6. 城市化率 (World Bank SP.URB.TOTL.IN.ZS) 1990-2023
7. 总人口 (World Bank SP.POP.TOTL) 1990-2023
8. GDP人均 (World Bank NY.GDP.PCAP.CD) 1990-2023

注：护理人员 (HWF_0008) 及其配套人口由 03_nurse_timeseries_cv.py 下载；
GBD 数据需手动从 GBD Results Tool 导出。所有原始数据归档到对应数据源目录。
"""
import os
import json
import urllib.request
import urllib.parse
import pandas as pd
import numpy as np

PARENT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WHO_DIR = os.path.join(PARENT, "WHO")
WB_DIR = os.path.join(PARENT, "WorldBank")
RESULTS = os.path.join(PARENT, "results")
os.makedirs(WHO_DIR, exist_ok=True)
os.makedirs(WB_DIR, exist_ok=True)
os.makedirs(RESULTS, exist_ok=True)


def who_gho_api(indicator_code, filename, label):
    """从WHO GHO API下载指标数据（字段名: TimeDim=年份, SpatialDim=国家ISO, NumericValue=值）"""
    url = f"https://ghoapi.azureedge.net/api/{indicator_code}"
    print(f"\n  下载 {label} ({indicator_code})...")
    print(f"  URL: {url}")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        records = data.get("value", [])
        print(f"  原始记录数: {len(records)}")
        if not records:
            print(f"  [警告] {label} 无数据返回")
            return pd.DataFrame()
        df = pd.DataFrame(records)
        # 统一字段名
        df = df.rename(columns={
            "TimeDim": "year",
            "SpatialDim": "iso3",
            "NumericValue": "value",
            "ParentLocation": "who_region",
            "Dim1": "dim1",
        })
        # 只保留国家级（SpatialDimType=COUNTRY）
        if "SpatialDimType" in df.columns:
            df = df[df["SpatialDimType"] == "COUNTRY"].copy()
        df["year"] = df["year"].astype(int)
        df["value"] = pd.to_numeric(df["value"], errors="coerce")
        keep_cols = ["iso3", "year", "value"]
        for c in ["who_region", "ParentLocationCode"]:
            if c in df.columns:
                keep_cols.append(c)
        df = df[[c for c in keep_cols if c in df.columns]].dropna(subset=["value"])
        print(f"  有效记录数: {len(df)}")
        print(f"  国家数: {df['iso3'].nunique()}")
        print(f"  年份范围: {df['year'].min()} ~ {df['year'].max()}")
        out_path = os.path.join(WHO_DIR, filename)
        df.to_csv(out_path, index=False)
        print(f"  已保存: {out_path}")
        return df
    except Exception as e:
        print(f"  [错误] {label} 下载失败: {e}")
        return pd.DataFrame()


def worldbank_api(indicator, filename, label, date_range="1990:2023"):
    """从World Bank API下载指标数据"""
    url = f"https://api.worldbank.org/v2/country/all/indicator/{indicator}?date={date_range}&format=json&per_page=20000"
    print(f"\n  下载 {label} ({indicator})...")
    print(f"  URL: {url}")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        if len(data) < 2 or not data[1]:
            print(f"  [警告] {label} 无数据返回")
            return pd.DataFrame()
        records = data[1]
        print(f"  原始记录数: {len(records)}")
        df = pd.DataFrame(records)
        # 过滤掉聚合区域（只保留国家，incomeLevel和region都非空的是国家）
        df = df[df["countryiso3code"].notna() & (df["countryiso3code"] != "")]
        df = df.rename(columns={
            "countryiso3code": "iso3",
            "country": "country_name",
            "date": "year",
            "value": "value",
            "indicator": "indicator"
        })
        df["year"] = df["year"].astype(int)
        df = df[["iso3", "country_name", "year", "value"]].copy()
        df["value"] = pd.to_numeric(df["value"], errors="coerce")
        df = df.dropna(subset=["value"])
        print(f"  有效记录数: {len(df)}")
        print(f"  国家数: {df['iso3'].nunique()}")
        print(f"  年份范围: {df['year'].min()} ~ {df['year'].max()}")
        out_path = os.path.join(WB_DIR, filename)
        df.to_csv(out_path, index=False)
        print(f"  已保存: {out_path}")
        return df
    except Exception as e:
        print(f"  [错误] {label} 下载失败: {e}")
        return pd.DataFrame()


def main():
    print("=" * 70)
    print("路线C补充数据下载")
    print("=" * 70)

    # ===== 1. WHO GHO: 医生人数 (HWF_0002 = Medical doctors number) =====
    doc_df = who_gho_api("HWF_0002", "HWF_0002_medical_doctors_timeseries.csv", "医生人数")

    # ===== 2. WHO GHO: 医生密度 (HWF_0001 = Medical doctors per 10,000) =====
    doc_density_df = who_gho_api("HWF_0001", "HWF_0001_medical_doctors_density.csv", "医生密度(每万人)")

    # ===== 3. WHO GHO: 医院床位 (WHS6_102 = Hospital beds per 10,000 population) =====
    bed_df = who_gho_api("WHS6_102", "WHS6_102_hospital_beds_per10k.csv", "医院床位(每万人)")

    # ===== 4. WHO GHO: UHC服务覆盖指数 (UHC_INDEX_REPORTED = SDG 3.8.1) =====
    uhc_who_df = who_gho_api("UHC_INDEX_REPORTED", "UHC_INDEX_REPORTED_sci_sdg381.csv",
                             "UHC服务覆盖指数(WHO)")

    # ===== 4. World Bank: GNI人均 (Atlas法) 1990-2023 =====
    gni_df = worldbank_api("NY.GNP.PCAP.CD", "gni_per_capita_atlas_1990_2023.csv",
                           "GNI人均(Atlas法) 1990-2023")

    # ===== 5. World Bank: 城市化率 =====
    urb_df = worldbank_api("SP.URB.TOTL.IN.ZS", "urban_population_pct_1990_2023.csv",
                           "城市化率 1990-2023")

    # ===== 6. World Bank: UHC服务覆盖指数 (尝试备选indicator) =====
    uhc_df = worldbank_api("SH.UHC.SRVS.CV.IN", "uhc_service_coverage_index.csv",
                           "UHC服务覆盖指数(WB)")
    # 如果WB的UHC失败，用WHO的替代
    if uhc_df is None or len(uhc_df) == 0:
        print("  [信息] WB UHC无数据，使用WHO GHO的UHC_INDEX_REPORTED替代")
        uhc_df = uhc_who_df

    # ===== 7. World Bank: 人口 (用于计算密度) =====
    pop_df = worldbank_api("SP.POP.TOTL", "total_population_1990_2023.csv",
                           "总人口 1990-2023")

    # ===== 8. World Bank: GDP人均 (用于二阶段回归) =====
    gdp_df = worldbank_api("NY.GDP.PCAP.CD", "gdp_per_capita_1990_2023.csv",
                           "GDP人均 1990-2023")

    # ===== 汇总 =====
    print("\n" + "=" * 70)
    print("下载完成汇总")
    print("=" * 70)
    downloads = [
        ("WHO/HWF_0002_medical_doctors_timeseries.csv", "医生人数", doc_df),
        ("WHO/HWF_0001_medical_doctors_density.csv", "医生密度", doc_density_df),
        ("WHO/WHS6_102_hospital_beds_per10k.csv", "医院床位", bed_df),
        ("WHO/UHC_INDEX_REPORTED_sci_sdg381.csv", "UHC指数(WHO)", uhc_who_df),
        ("WorldBank/gni_per_capita_atlas_1990_2023.csv", "GNI人均", gni_df),
        ("WorldBank/urban_population_pct_1990_2023.csv", "城市化率", urb_df),
        ("WorldBank/uhc_service_coverage_index.csv", "UHC指数(WB)", uhc_df if uhc_df is not uhc_who_df else pd.DataFrame()),
        ("WorldBank/total_population_1990_2023.csv", "总人口", pop_df),
        ("WorldBank/gdp_per_capita_1990_2023.csv", "GDP人均", gdp_df),
    ]
    for path, label, df in downloads:
        if df is not None and len(df) > 0:
            print(f"  [OK] {path:55s} {len(df):>6d} 行")
        else:
            print(f"  [缺失] {path:55s} 下载失败")


if __name__ == "__main__":
    main()
