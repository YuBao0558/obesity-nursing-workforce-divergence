"""
护理人力密度时间序列稳定性检验（SA-3）。

目的：
  验证"护理人力密度作为结构性存量指标，年度间变化缓慢"这一方法学辩护假设。
  如果多数国家 2019 前后护理密度的变异系数(CV) < 0.10，
  则说明用 2022/2023 年护理密度替代 2019 年不会实质改变 DEA 结果。

数据源：
  WHO GHO OData API  HWF_0008 = Nursing personnel (number), ISCO 2221+3221
  World Bank WDI      SP.POP.TOTL = 总人口

输出：
  results/nurse_timeseries.csv       逐国逐年护理密度（2014-2023 全量）
  results/nurse_cv_summary.csv       逐国 CV 汇总 + 可用年份数
  results/nurse_cv_overall.csv       全局统计：中位CV、CV<0.10占比等
"""
import json
import urllib.request
import pandas as pd
import numpy as np
import os
import time

PARENT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESULTS = os.path.join(PARENT, "results")
WHO_DIR = os.path.join(PARENT, "WHO")
os.makedirs(RESULTS, exist_ok=True)
os.makedirs(WHO_DIR, exist_ok=True)

# ISO 3166-1 alpha-2 -> alpha-3（与 07_nurse_pure_density.py 一致）
ISO2_TO_ISO3 = {
    "AD": "AND", "AE": "ARE", "AF": "AFG", "AG": "ATG", "AL": "ALB", "AM": "ARM",
    "AO": "AGO", "AR": "ARG", "AT": "AUT", "AU": "AUS", "AZ": "AZE", "BA": "BIH",
    "BB": "BRB", "BD": "BGD", "BE": "BEL", "BF": "BFA", "BG": "BGR", "BH": "BHR",
    "BI": "BDI", "BJ": "BEN", "BN": "BRN", "BO": "BOL", "BR": "BRA", "BS": "BHS",
    "BT": "BTN", "BW": "BWA", "BY": "BLR", "BZ": "BLZ", "CA": "CAN", "CD": "COD",
    "CF": "CAF", "CG": "COG", "CH": "CHE", "CI": "CIV", "CL": "CHL", "CM": "CMR",
    "CN": "CHN", "CO": "COL", "CR": "CRI", "CU": "CUB", "CV": "CPV", "CY": "CYP",
    "CZ": "CZE", "DE": "DEU", "DJ": "DJI", "DK": "DNK", "DM": "DMA", "DO": "DOM",
    "DZ": "DZA", "EC": "ECU", "EE": "EST", "EG": "EGY", "ER": "ERI", "ES": "ESP",
    "ET": "ETH", "FI": "FIN", "FJ": "FJI", "FM": "FSM", "FR": "FRA", "GA": "GAB",
    "GB": "GBR", "GD": "GRD", "GE": "GEO", "GH": "GHA", "GM": "GMB", "GN": "GIN",
    "GQ": "GNQ", "GR": "GRC", "GT": "GTM", "GW": "GNB", "GY": "GUY", "HN": "HND",
    "HR": "HRV", "HT": "HTI", "HU": "HUN", "ID": "IDN", "IE": "IRL", "IL": "ISR",
    "IN": "IND", "IQ": "IRQ", "IR": "IRN", "IS": "ISL", "IT": "ITA", "JM": "JAM",
    "JO": "JOR", "JP": "JPN", "KE": "KEN", "KG": "KGZ", "KH": "KHM", "KI": "KIR",
    "KM": "COM", "KN": "KNA", "KP": "PRK", "KR": "KOR", "KW": "KWT", "KZ": "KAZ",
    "LA": "LAO", "LB": "LBN", "LC": "LCA", "LI": "LIE", "LK": "LKA", "LR": "LBR",
    "LS": "LSO", "LT": "LTU", "LU": "LUX", "LV": "LVA", "LY": "LBY", "MA": "MAR",
    "MC": "MCO", "MD": "MDA", "ME": "MNE", "MG": "MDG", "MH": "MHL", "MK": "MKD",
    "ML": "MLI", "MM": "MMR", "MN": "MNG", "MR": "MRT", "MT": "MLT", "MU": "MUS",
    "MV": "MDV", "MW": "MWI", "MX": "MEX", "MY": "MYS", "MZ": "MOZ", "NA": "NAM",
    "NE": "NER", "NG": "NGA", "NI": "NIC", "NL": "NLD", "NO": "NOR", "NP": "NPL",
    "NR": "NRU", "NZ": "NZL", "OM": "OMN", "PA": "PAN", "PE": "PER", "PG": "PNG",
    "PH": "PHL", "PK": "PAK", "PL": "POL", "PT": "PRT", "PW": "PLW", "PY": "PRY",
    "QA": "QAT", "RO": "ROU", "RS": "SRB", "RU": "RUS", "RW": "RWA", "SA": "SAU",
    "SB": "SLB", "SC": "SYC", "SD": "SDN", "SE": "SWE", "SG": "SGP", "SI": "SVN",
    "SK": "SVK", "SL": "SLE", "SM": "SMR", "SN": "SEN", "SO": "SOM", "SR": "SUR",
    "SS": "SSD", "ST": "STP", "SV": "SLV", "SY": "SYR", "SZ": "SWZ", "TD": "TCD",
    "TG": "TGO", "TH": "THA", "TJ": "TJK", "TL": "TLS", "TM": "TKM", "TN": "TUN",
    "TO": "TON", "TR": "TUR", "TT": "TTO", "TV": "TUV", "TZ": "TZA", "UA": "UKR",
    "UG": "UGA", "US": "USA", "UY": "URY", "UZ": "UZB", "VC": "VCT", "VE": "VEN",
    "VN": "VNM", "VU": "VUT", "WS": "WSM", "YE": "YEM", "ZA": "ZAF", "ZM": "ZMB",
    "ZW": "ZWE",
}


def gho_get(code):
    """拉取 GHO 指标的全部年份数据（不取最新年，保留全部时间序列）"""
    url = f"https://ghoapi.azureedge.net/api/{code}"
    with urllib.request.urlopen(url, timeout=120) as r:
        data = json.load(r)
    rows = []
    for x in data["value"]:
        if x.get("SpatialDimType") != "COUNTRY":
            continue
        out_val = x.get("NumericValue")
        if out_val is None:
            continue
        rows.append({
            "iso3": x["SpatialDim"],
            "who_region": x.get("ParentLocation"),
            "year": x["TimeDim"],
            "nurse_number": out_val,
        })
    df = pd.DataFrame(rows)
    df["year"] = pd.to_numeric(df["year"], errors="coerce")
    df["nurse_number"] = pd.to_numeric(df["nurse_number"], errors="coerce")
    return df.dropna(subset=["year", "nurse_number"])


def wb_pop_get():
    """拉取 World Bank 人口 2014-2023，返回逐国逐年"""
    url = ("https://api.worldbank.org/v2/country/all/indicator/SP.POP.TOTL"
           "?format=json&per_page=20000&date=2014:2023")
    with urllib.request.urlopen(url, timeout=120) as r:
        data = json.load(r)
    rows = []
    for x in data[1]:
        if x.get("value") is None:
            continue
        iso2 = x["country"]["id"]
        iso3 = ISO2_TO_ISO3.get(iso2)
        if iso3 is None:
            continue
        rows.append({
            "iso3": iso3,
            "year": int(x["date"]),
            "population": x["value"],
        })
    return pd.DataFrame(rows)


def run():
    print("=" * 60)
    print("护理人力密度时间序列稳定性检验 (SA-3)")
    print("=" * 60)

    # 1. 拉取全量护理人数（保留所有年份）
    print("\n[1/4] 拉取 GHO HWF_0008 全量时间序列...")
    nurse_all = gho_get("HWF_0008")
    print(f"  护理人数观测: {len(nurse_all)} 行, {nurse_all['iso3'].nunique()} 国")
    print(f"  年份范围: {int(nurse_all['year'].min())} ~ {int(nurse_all['year'].max())}")

    # 2. 拉取人口
    print("\n[2/4] 拉取 World Bank 人口...")
    pop = wb_pop_get()
    print(f"  人口观测: {len(pop)} 行, {pop['iso3'].nunique()} 国")

    # 3. 合并算逐年密度
    print("\n[3/4] 合并计算逐年护理密度...")
    dens = nurse_all.merge(pop, on=["iso3", "year"], how="left")
    dens = dens[dens["population"] > 0]
    dens["nurse_per10k"] = dens["nurse_number"] / dens["population"] * 1e4
    dens = dens[dens["nurse_per10k"] > 0]

    # 逐年统计
    yr_stats = dens.groupby("year").agg(
        n_countries=("iso3", "nunique"),
        median_density=("nurse_per10k", "median"),
    ).reset_index()
    print("\n  逐年份覆盖情况:")
    print(yr_stats.to_string(index=False))

    # 保存原始 API 下载数据到 WHO/ 目录（数据归档）
    who_raw = nurse_all[["iso3", "who_region", "year", "nurse_number"]].copy()
    who_raw = who_raw.sort_values(["iso3", "year"])
    who_raw.to_csv(os.path.join(WHO_DIR, "HWF_0008_nursing_personnel_timeseries.csv"), index=False)
    print(f"\n  WHO 原始数据归档: WHO/HWF_0008_nursing_personnel_timeseries.csv ({len(who_raw)} 行)")

    pop_raw = pop.sort_values(["iso3", "year"])
    pop_raw.to_csv(os.path.join(WHO_DIR, "worldbank_population_2014_2023.csv"), index=False)
    print(f"  World Bank 人口归档: WHO/worldbank_population_2014_2023.csv ({len(pop_raw)} 行)")

    # 保存完整时间序列（含计算密度）到 results/
    dens.to_csv(os.path.join(RESULTS, "nurse_timeseries.csv"), index=False)
    print(f"  分析用时间序列: results/nurse_timeseries.csv ({len(dens)} 行)")

    # 4. 计算每国 CV（变异系数）
    print("\n[4/4] 计算各国护理密度变异系数 (CV)...")

    cv_records = []
    for iso3, grp in dens.groupby("iso3"):
        vals = grp.sort_values("year")
        n_years = len(vals)
        if n_years < 2:
            # 只有单年数据，无法算 CV
            cv_records.append({
                "iso3": iso3,
                "n_years": n_years,
                "year_min": int(vals["year"].min()),
                "year_max": int(vals["year"].max()),
                "density_mean": vals["nurse_per10k"].mean(),
                "density_std": np.nan,
                "cv": np.nan,
                "has_2019": 2019 in vals["year"].values,
                "density_2019": vals.loc[vals["year"] == 2019, "nurse_per10k"].values[0]
                                if 2019 in vals["year"].values else np.nan,
                "density_latest": vals["nurse_per10k"].iloc[-1],
                "year_latest": int(vals["year"].iloc[-1]),
                "pct_change_latest_vs_2019": (
                    (vals["nurse_per10k"].iloc[-1] - vals.loc[vals["year"] == 2019, "nurse_per10k"].values[0])
                    / vals.loc[vals["year"] == 2019, "nurse_per10k"].values[0] * 100
                ) if (2019 in vals["year"].values and vals["nurse_per10k"].iloc[-1] > 0) else np.nan,
            })
            continue

        mean_v = vals["nurse_per10k"].mean()
        std_v = vals["nurse_per10k"].std(ddof=1)
        cv = std_v / mean_v if mean_v > 0 else np.nan

        # 如果有 2019 年数据，算 2019 与最新年的百分比变化
        d2019 = vals.loc[vals["year"] == 2019, "nurse_per10k"].values
        d_latest = vals["nurse_per10k"].iloc[-1]
        y_latest = int(vals["year"].iloc[-1])
        if len(d2019) > 0 and d2019[0] > 0:
            pct_change = (d_latest - d2019[0]) / d2019[0] * 100
        else:
            pct_change = np.nan

        cv_records.append({
            "iso3": iso3,
            "n_years": n_years,
            "year_min": int(vals["year"].min()),
            "year_max": int(vals["year"].max()),
            "density_mean": mean_v,
            "density_std": std_v,
            "cv": cv,
            "has_2019": 2019 in vals["year"].values,
            "density_2019": d2019[0] if len(d2019) > 0 else np.nan,
            "density_latest": d_latest,
            "year_latest": y_latest,
            "pct_change_latest_vs_2019": pct_change,
        })

    cv_df = pd.DataFrame(cv_records)
    cv_df = cv_df.sort_values("cv", na_position="last")
    cv_df.to_csv(os.path.join(RESULTS, "nurse_cv_summary.csv"), index=False)
    print(f"  逐国 CV 已保存: results/nurse_cv_summary.csv ({len(cv_df)} 国)")

    # 全局统计
    cv_valid = cv_df.dropna(subset=["cv"])
    overall = {
        "total_countries": len(cv_df),
        "countries_with_multistep_cv": len(cv_valid),
        "countries_single_year": len(cv_df) - len(cv_valid),
        "median_cv": cv_valid["cv"].median(),
        "mean_cv": cv_valid["cv"].mean(),
        "q25_cv": cv_valid["cv"].quantile(0.25),
        "q75_cv": cv_valid["cv"].quantile(0.75),
        "pct_cv_lt_005": (cv_valid["cv"] < 0.05).mean() * 100,
        "pct_cv_lt_010": (cv_valid["cv"] < 0.10).mean() * 100,
        "pct_cv_lt_015": (cv_valid["cv"] < 0.15).mean() * 100,
        "pct_cv_lt_020": (cv_valid["cv"] < 0.20).mean() * 100,
        "median_n_years": cv_valid["n_years"].median(),
        "max_n_years": int(cv_valid["n_years"].max()),
    }

    # 同时统计：有 2019 年数据且也有 >2019 年数据的国家中，
    # 最新年 vs 2019 年的百分比变化分布
    has_both = cv_df.dropna(subset=["pct_change_latest_vs_2019"])
    if len(has_both) > 0:
        overall["n_countries_has_2019_and_later"] = len(has_both)
        overall["median_pct_change"] = has_both["pct_change_latest_vs_2019"].median()
        overall["mean_pct_change"] = has_both["pct_change_latest_vs_2019"].mean()
        overall["pct_abs_change_lt_5pct"] = (has_both["pct_change_latest_vs_2019"].abs() < 5).mean() * 100
        overall["pct_abs_change_lt_10pct"] = (has_both["pct_change_latest_vs_2019"].abs() < 10).mean() * 100
        overall["pct_abs_change_lt_20pct"] = (has_both["pct_change_latest_vs_2019"].abs() < 20).mean() * 100

    overall_df = pd.DataFrame([overall])
    overall_df.to_csv(os.path.join(RESULTS, "nurse_cv_overall.csv"), index=False)

    print("\n" + "=" * 60)
    print("全局统计摘要")
    print("=" * 60)
    print(f"  总国家数:                   {overall['total_countries']}")
    print(f"  有多年数据可算CV的国家:     {overall['countries_with_multistep_cv']}")
    print(f"  仅单年数据的国家:           {overall['countries_single_year']}")
    print(f"  CV 中位数:                  {overall['median_cv']:.4f}")
    print(f"  CV 均值:                    {overall['mean_cv']:.4f}")
    print(f"  CV IQR:                     [{overall['q25_cv']:.4f}, {overall['q75_cv']:.4f}]")
    print(f"  CV < 0.05 占比:             {overall['pct_cv_lt_005']:.1f}%")
    print(f"  CV < 0.10 占比:             {overall['pct_cv_lt_010']:.1f}%")
    print(f"  CV < 0.15 占比:             {overall['pct_cv_lt_015']:.1f}%")
    print(f"  CV < 0.20 占比:             {overall['pct_cv_lt_020']:.1f}%")
    print(f"  可用年份数中位数:           {overall['median_n_years']}")
    print(f"  最多可用年份:               {overall['max_n_years']}")

    if "n_countries_has_2019_and_later" in overall:
        print(f"\n  同时有2019年及更新年数据的国家: {overall['n_countries_has_2019_and_later']}")
        print(f"  最新年 vs 2019年 变化中位数:     {overall['median_pct_change']:.2f}%")
        print(f"  最新年 vs 2019年 变化均值:       {overall['mean_pct_change']:.2f}%")
        print(f"  |变化| < 5% 占比:                {overall['pct_abs_change_lt_5pct']:.1f}%")
        print(f"  |变化| < 10% 占比:               {overall['pct_abs_change_lt_10pct']:.1f}%")
        print(f"  |变化| < 20% 占比:               {overall['pct_abs_change_lt_20pct']:.1f}%")

    print("\n  结论:")
    if overall["pct_cv_lt_010"] >= 70:
        print("  ✓ 多数国家(≥70%) CV < 0.10，护理密度年度间变异极小，")
        print("    '结构性存量指标变化缓慢'的假设得到支持。")
        print("    → SA-3 可作为强有力的方法学辩护。")
    elif overall["pct_cv_lt_020"] >= 70:
        print("  △ 多数国家 CV < 0.20 但 ≥0.10 比例不低，")
        print("    需结合 |变化| < 10% 占比综合判断。")
    else:
        print("  ✗ 多数国家 CV ≥ 0.20，护理密度年度间变化较大，")
        print("    '结构性存量指标'的辩护假设可能不成立，")
        print("    需更多依赖 SA-1/SA-2 的直接敏感性分析。")

    print(f"\n输出文件:")
    print(f"  results/nurse_timeseries.csv  (逐国逐年密度)")
    print(f"  results/nurse_cv_summary.csv  (逐国CV汇总)")
    print(f"  results/nurse_cv_overall.csv  (全局统计)")


if __name__ == "__main__":
    run()
