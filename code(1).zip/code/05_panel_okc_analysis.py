"""
路线C - 面板数据构建 + 肥胖负担库兹涅茨曲线(OKC)分析
================================================================
构建1990-2023面板数据集，包含：
- GBD 2023 高BMI DALY (5个时间点: 1990, 2000, 2010, 2020, 2023)
- World Bank GNI人均、城市化率、GDP人均
- WHO 护理/医生/床位密度
- WHO UHC服务覆盖指数

分析方法：
1. 横截面OLS OKC (基准)
2. 面板固定效应OKC (控制不可观测国家异质性)
3. 调节变量分析 (城市化率、收入分组)
"""
import os
import sys
import warnings
import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import linprog
import statsmodels.api as sm
from statsmodels.regression.linear_model import OLS

# 导入项目已有的 location_id -> ISO3 映射
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from importlib import import_module
loc_map_mod = import_module("02_location_id_map")
LOC_ID_TO_ISO3 = loc_map_mod.LOC_ID_ID_TO_ISO3 if hasattr(loc_map_mod, "LOC_ID_ID_TO_ISO3") else loc_map_mod.LOC_ID_TO_ISO3

warnings.filterwarnings("ignore")

PARENT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GBD_DIR = os.path.join(PARENT, "GBD")
WHO_DIR = os.path.join(PARENT, "WHO")
WB_DIR = os.path.join(PARENT, "WorldBank")
RESULTS = os.path.join(PARENT, "results")
os.makedirs(RESULTS, exist_ok=True)

INCOME_GROUPS = {}  # 不再使用硬编码分组，改用GNI动态分组


def load_gbd_bmi_panel():
    """从GBD 2023数据构建高BMI DALY面板数据"""
    print("\n[1] 构建GBD高BMI DALY面板数据...")
    frames = []
    gbd_files = {
        1990: os.path.join(GBD_DIR, "IHME-GBD_2023_DATA-f084eb06-1"),
        2000: os.path.join(GBD_DIR, "IHME-GBD_2023_DATA-606b87aa-1"),
        2010: os.path.join(GBD_DIR, "IHME-GBD_2023_DATA-a8103292-1"),
        2020: os.path.join(GBD_DIR, "IHME-GBD_2023_DATA-cd853232-1"),
        2023: os.path.join(GBD_DIR, "IHME-GBD_2023_DATA-664a6eb3-1"),
    }
    for year, dpath in gbd_files.items():
        csv_files = [f for f in os.listdir(dpath) if f.endswith(".csv") or f.endswith(".CSV")]
        if not csv_files:
            continue
        df = pd.read_csv(os.path.join(dpath, csv_files[0]))
        # 筛选高BMI
        bmi = df[df["rei_name"].astype(str).str.contains("BMI", case=False, na=False)].copy()
        # 筛选DALY、年龄标准化、合计性别、率（每10万人）、所有原因（避免子原因重复）
        bmi = bmi[
            (bmi["measure_name"] == "伤残调整生命年") &
            (bmi["age_name"] == "年龄标准化") &
            (bmi["sex_name"] == "合计") &
            (bmi["metric_name"] == "率") &
            (bmi["cause_name"].astype(str).str.contains("所有原因", case=False, na=False))
        ].copy()
        bmi = bmi.rename(columns={"location_name": "country_name"})
        bmi["bmi_daly_rate"] = bmi["val"]  # DALY率（每10万人）
        # 用 location_id 映射到 ISO3（跨语言稳定）
        bmi["iso3"] = bmi["location_id"].map(LOC_ID_TO_ISO3)
        bmi = bmi[["location_id", "country_name", "iso3", "bmi_daly_rate"]].copy()
        bmi = bmi.dropna(subset=["iso3"])  # 只保留有ISO3映射的国家
        bmi["year"] = year
        frames.append(bmi)
        print(f"  {year}: {len(bmi)} 国 (映射后)")

    panel = pd.concat(frames, ignore_index=True)
    print(f"  合并面板: {len(panel)} 行, {panel['iso3'].nunique()} 国, "
          f"{panel['year'].nunique()} 个时间点")
    return panel


def load_gni_panel():
    """加载GNI人均时间序列"""
    print("\n[2] 加载GNI面板...")
    gni = pd.read_csv(os.path.join(WB_DIR, "gni_per_capita_atlas_1990_2023.csv"))
    gni = gni.rename(columns={"value": "gni_pc"})
    gni = gni[["iso3", "year", "gni_pc"]].copy()
    # 匹配GBD的5个时间点 + 附近年份
    target_years = [1990, 2000, 2010, 2020, 2023]
    gni_panel = gni[gni["year"].isin(target_years)].copy()
    print(f"  GNI面板: {len(gni_panel)} 行, {gni_panel['iso3'].nunique()} 国")
    return gni, gni_panel


def load_urbanization():
    """加载城市化率"""
    print("\n[3] 加载城市化率...")
    urb = pd.read_csv(os.path.join(WB_DIR, "urban_population_pct_1990_2023.csv"))
    urb = urb.rename(columns={"value": "urban_pct"})
    urb = urb[["iso3", "year", "urban_pct"]].copy()
    print(f"  城市化率: {len(urb)} 行, {urb['iso3'].nunique()} 国")
    return urb


def load_workforce_density():
    """加载护理/医生/床位密度（多投入DEA需要）"""
    print("\n[4] 加载卫生人力密度...")

    # 护理密度（每万人）- 已有时间序列
    nurse_ts = pd.read_csv(os.path.join(RESULTS, "nurse_timeseries.csv"))
    nurse = nurse_ts[["iso3", "year", "nurse_per10k"]].copy()

    # 医生密度（每万人）
    doc = pd.read_csv(os.path.join(WHO_DIR, "HWF_0001_medical_doctors_density.csv"))
    doc = doc.rename(columns={"value": "doc_per10k"})
    doc = doc[["iso3", "year", "doc_per10k"]].copy()

    # 床位（每万人）
    bed = pd.read_csv(os.path.join(WHO_DIR, "WHS6_102_hospital_beds_per10k.csv"))
    bed = bed.rename(columns={"value": "bed_per10k"})
    bed = bed[["iso3", "year", "bed_per10k"]].copy()

    print(f"  护理: {len(nurse)} 行, {nurse['iso3'].nunique()} 国")
    print(f"  医生: {len(doc)} 行, {doc['iso3'].nunique()} 国")
    print(f"  床位: {len(bed)} 行, {bed['iso3'].nunique()} 国")

    return nurse, doc, bed


def load_uhc():
    """加载UHC服务覆盖指数"""
    print("\n[5] 加载UHC指数...")
    uhc = pd.read_csv(os.path.join(WHO_DIR, "UHC_INDEX_REPORTED_sci_sdg381.csv"))
    uhc = uhc.rename(columns={"value": "uhc_index"})
    uhc = uhc[["iso3", "year", "uhc_index"]].copy()
    print(f"  UHC: {len(uhc)} 行, {uhc['iso3'].nunique()} 国")
    return uhc


def build_master_panel():
    """构建主面板数据集"""
    print("=" * 70)
    print("构建路线C主面板数据集")
    print("=" * 70)

    # 1. GBD高BMI DALY面板
    bmi_panel = load_gbd_bmi_panel()

    # 2. GNI
    gni_full, gni_panel = load_gni_panel()

    # 3. 城市化率
    urb = load_urbanization()

    # 4. 卫生人力
    nurse, doc, bed = load_workforce_density()

    # 5. UHC
    uhc = load_uhc()

    # ISO3已在load_gbd_bmi_panel中通过location_id映射完成
    unmapped = bmi_panel[bmi_panel["iso3"].isna()]
    if len(unmapped) > 0:
        print(f"\n  [信息] {len(unmapped)} 行GBD数据无ISO3映射（地区汇总/SDI分组，已排除）")
    bmi_panel = bmi_panel.dropna(subset=["iso3"])
    print(f"\n  匹配后GBD面板: {len(bmi_panel)} 行, {bmi_panel['iso3'].nunique()} 国")

    # 合并GNI
    panel = bmi_panel.merge(gni_panel, on=["iso3", "year"], how="left")

    # 合并城市化率（取目标年份的最近值）
    target_years = [1990, 2000, 2010, 2020, 2023]
    urb_panel = urb[urb["year"].isin(target_years)].copy()
    panel = panel.merge(urb_panel, on=["iso3", "year"], how="left")

    # 合并卫生人力（对每个目标年份取最近可得值）
    for label, df_hr, val_col in [("nurse", nurse, "nurse_per10k"),
                                    ("doc", doc, "doc_per10k"),
                                    ("bed", bed, "bed_per10k")]:
        hr_filled = []
        for iso3 in panel["iso3"].unique():
            for ty in target_years:
                sub = df_hr[(df_hr["iso3"] == iso3)].copy()
                if len(sub) == 0:
                    continue
                # 取目标年份最近的值
                sub["dist"] = (sub["year"] - ty).abs()
                best = sub.sort_values("dist").iloc[0]
                hr_filled.append({
                    "iso3": iso3,
                    "year": ty,
                    f"{label}_per10k": best[val_col],
                    f"{label}_source_year": int(best["year"]),
                })
        hr_df = pd.DataFrame(hr_filled)
        panel = panel.merge(hr_df, on=["iso3", "year"], how="left")

    # 合并UHC（同样的最近年份策略）
    uhc_filled = []
    for iso3 in panel["iso3"].unique():
        for ty in target_years:
            sub = uhc[(uhc["iso3"] == iso3)].copy()
            if len(sub) == 0:
                continue
            sub["dist"] = (sub["year"] - ty).abs()
            best = sub.sort_values("dist").iloc[0]
            uhc_filled.append({
                "iso3": iso3,
                "year": ty,
                "uhc_index": best["uhc_index"],
                "uhc_source_year": int(best["year"]),
            })
    uhc_df = pd.DataFrame(uhc_filled)
    panel = panel.merge(uhc_df, on=["iso3", "year"], how="left")

    # 合并HAQ（2019年固定值，对所有年份都用同一个）
    haq = pd.read_csv(os.path.join(RESULTS, "haq_merge.csv"))
    haq_map = haq.set_index("iso3")["haq_2019"].to_dict()
    panel["haq_2019"] = panel["iso3"].map(haq_map)

    # 计算ln变换
    panel["ln_gni"] = np.log(panel["gni_pc"].clip(lower=1))
    panel["ln_gni2"] = panel["ln_gni"] ** 2
    panel["ln_gni3"] = panel["ln_gni"] ** 3
    panel["ln_bmi_daly"] = np.log(panel["bmi_daly_rate"].clip(lower=0.01))
    panel["ln_urban"] = np.log(panel["urban_pct"].clip(lower=0.01))

    # 收入分组（基于GNI 2023）
    def income_group(gni):
        if pd.isna(gni):
            return np.nan
        if gni <= 1135:
            return "Low"
        elif gni <= 4465:
            return "Lower-middle"
        elif gni <= 13845:
            return "Upper-middle"
        else:
            return "High"

    panel["income_group"] = panel.apply(
        lambda r: income_group(gni_full[(gni_full["iso3"] == r["iso3"]) &
                                        (gni_full["year"] == r["year"])]["gni_pc"].values[0])
        if len(gni_full[(gni_full["iso3"] == r["iso3"]) & (gni_full["year"] == r["year"])]) > 0
        else income_group(r["gni_pc"]), axis=1
    )

    print(f"\n  最终面板: {len(panel)} 行, {panel['iso3'].nunique()} 国")
    print(f"  完整数据(无缺失): {len(panel.dropna(subset=['ln_gni','ln_bmi_daly','urban_pct']))} 行")

    return panel, gni_full


# ============================================================
# OKC分析
# ============================================================

def okc_pooled_ols(panel):
    """混合OLS横截面OKC回归"""
    print("\n" + "=" * 70)
    print("[OKC分析 1] 混合OLS横截面回归")
    print("=" * 70)

    results_by_year = {}
    for year in sorted(panel["year"].unique()):
        sub = panel[panel["year"] == year].dropna(subset=["ln_gni", "ln_bmi_daly"])
        if len(sub) < 20:
            continue
        X = sm.add_constant(sub[["ln_gni", "ln_gni2"]])
        y = sub["ln_bmi_daly"]
        model = OLS(y, X).fit()
        results_by_year[year] = {
            "n": len(sub),
            "beta_gni": model.params["ln_gni"],
            "beta_gni2": model.params["ln_gni2"],
            "se_gni": model.bse["ln_gni"],
            "se_gni2": model.bse["ln_gni2"],
            "p_gni": model.pvalues["ln_gni"],
            "p_gni2": model.pvalues["ln_gni2"],
            "r2": model.rsquared,
            "r2_adj": model.rsquared_adj,
            "turning_point_gni": np.exp(-model.params["ln_gni"] / (2 * model.params["ln_gni2"]))
            if model.params["ln_gni2"] < 0 else np.nan,
        }
        tp = results_by_year[year]["turning_point_gni"]
        print(f"  {year}: n={len(sub):>3d}, β₁={model.params['ln_gni']:>8.4f} (p={model.pvalues['ln_gni']:.4f}), "
              f"β₂={model.params['ln_gni2']:>8.4f} (p={model.pvalues['ln_gni2']:.4f}), "
              f"R²={model.rsquared:.3f}, 拐点GNI=${tp:,.0f}" if not np.isnan(tp)
              else f"  {year}: n={len(sub):>3d}, β₁={model.params['ln_gni']:>8.4f} (p={model.pvalues['ln_gni']:.4f}), "
              f"β₂={model.params['ln_gni2']:>8.4f} (p={model.pvalues['ln_gni2']:.4f}), "
              f"R²={model.rsquared:.3f}, 无拐点(β₂≥0)")

    df_res = pd.DataFrame(results_by_year).T
    df_res.index.name = "year"
    df_res.to_csv(os.path.join(RESULTS, "okc_pooled_by_year.csv"))
    return df_res


def okc_panel_fe(panel):
    """面板固定效应OKC回归（控制国家异质性）"""
    print("\n" + "=" * 70)
    print("[OKC分析 2] 面板固定效应回归")
    print("=" * 70)

    sub = panel.dropna(subset=["ln_gni", "ln_bmi_daly"]).copy()
    # 创建国家虚拟变量（固定效应）
    country_dummies = pd.get_dummies(sub["iso3"], prefix="fe", drop_first=True).astype(float)
    year_dummies = pd.get_dummies(sub["year"], prefix="yr", drop_first=True).astype(float)

    X = pd.concat([sub[["ln_gni", "ln_gni2"]], country_dummies, year_dummies], axis=1)
    X = sm.add_constant(X)
    y = sub["ln_bmi_daly"]

    model = OLS(y, X).fit()

    print(f"  n={model.nobs:.0f}, 国家数={sub['iso3'].nunique()}, 年份数={sub['year'].nunique()}")
    print(f"  β₁(GNI) = {model.params['ln_gni']:>10.4f} (SE={model.bse['ln_gni']:.4f}, p={model.pvalues['ln_gni']:.4f})")
    print(f"  β₂(GNI²) = {model.params['ln_gni2']:>10.4f} (SE={model.bse['ln_gni2']:.4f}, p={model.pvalues['ln_gni2']:.4f})")
    print(f"  R²(within) = {model.rsquared:.4f}, R²_adj = {model.rsquared_adj:.4f}")
    if model.params["ln_gni2"] < 0:
        tp = np.exp(-model.params["ln_gni"] / (2 * model.params["ln_gni2"]))
        print(f"  拐点 GNI = ${tp:,.0f}")

    # 加入城市化率作为调节变量
    sub2 = panel.dropna(subset=["ln_gni", "ln_bmi_daly", "urban_pct"]).copy()
    country_dummies2 = pd.get_dummies(sub2["iso3"], prefix="fe", drop_first=True).astype(float)
    year_dummies2 = pd.get_dummies(sub2["year"], prefix="yr", drop_first=True).astype(float)
    X2 = pd.concat([sub2[["ln_gni", "ln_gni2", "urban_pct"]], country_dummies2, year_dummies2], axis=1)
    X2 = sm.add_constant(X2)
    y2 = sub2["ln_bmi_daly"]
    model2 = OLS(y2, X2).fit()

    print(f"\n  [加入城市化率]")
    print(f"  n={model2.nobs:.0f}")
    print(f"  β₁(GNI) = {model2.params['ln_gni']:>10.4f} (p={model2.pvalues['ln_gni']:.4f})")
    print(f"  β₂(GNI²) = {model2.params['ln_gni2']:>10.4f} (p={model2.pvalues['ln_gni2']:.4f})")
    print(f"  β(城市化率) = {model2.params['urban_pct']:>10.4f} (p={model2.pvalues['urban_pct']:.4f})")
    print(f"  R² = {model2.rsquared:.4f}")

    return {
        "n": model.nobs,
        "beta_gni": model.params["ln_gni"],
        "beta_gni2": model.params["ln_gni2"],
        "se_gni": model.bse["ln_gni"],
        "se_gni2": model.bse["ln_gni2"],
        "p_gni": model.pvalues["ln_gni"],
        "p_gni2": model.pvalues["ln_gni2"],
        "r2": model.rsquared,
        "turning_point": np.exp(-model.params["ln_gni"] / (2 * model.params["ln_gni2"]))
        if model.params["ln_gni2"] < 0 else np.nan,
        "beta_urban": model2.params["urban_pct"],
        "p_urban": model2.pvalues["urban_pct"],
    }


def okc_income_group_analysis(panel):
    """收入分组内的OKC分析（检验高收入组内分化）"""
    print("\n" + "=" * 70)
    print("[OKC分析 4] 收入分组内分化分析")
    print("=" * 70)

    # 用2023年横截面
    sub = panel[panel["year"] == 2023].dropna(subset=["ln_gni", "ln_bmi_daly", "income_group"]).copy()
    print(f"  2023年横截面: n={len(sub)}, {sub['income_group'].value_counts().to_dict()}")

    results = {}
    for group in ["Low", "Lower-middle", "Upper-middle", "High"]:
        g = sub[sub["income_group"] == group]
        if len(g) < 5:
            continue
        print(f"\n  [{group}] n={len(g)}")
        print(f"    BMI DALY率: 中位{g['bmi_daly_rate'].median():.0f}/10万, "
              f"IQR [{g['bmi_daly_rate'].quantile(0.25):.0f}, {g['bmi_daly_rate'].quantile(0.75):.0f}]")
        print(f"    GNI: 中位${g['gni_pc'].median():,.0f}, "
              f"IQR [${g['gni_pc'].quantile(0.25):,.0f}, ${g['gni_pc'].quantile(0.75):,.0f}]")
        results[group] = {
            "n": len(g),
            "median_daly": g["bmi_daly_rate"].median(),
            "iqr_daly_low": g["bmi_daly_rate"].quantile(0.25),
            "iqr_daly_high": g["bmi_daly_rate"].quantile(0.75),
            "median_gni": g["gni_pc"].median(),
            "mean_urban": g["urban_pct"].mean(),
        }

    # Kruskal-Wallis检验各组DALY差异
    groups = [sub[sub["income_group"] == g]["bmi_daly_rate"].values
              for g in ["Low", "Lower-middle", "Upper-middle", "High"]
              if len(sub[sub["income_group"] == g]) > 0]
    if len(groups) >= 2:
        kw_stat, kw_p = stats.kruskal(*groups)
        print(f"\n  Kruskal-Wallis检验: H={kw_stat:.2f}, p={kw_p:.4e}")

    return pd.DataFrame(results).T


def main():
    # 构建面板
    panel, gni_full = build_master_panel()

    # 保存面板
    panel.to_csv(os.path.join(RESULTS, "panel_master_routeC.csv"), index=False)
    print(f"\n  主面板已保存: results/panel_master_routeC.csv ({len(panel)} 行)")

    # OKC分析（横截面OLS + 面板固定效应）
    okc_pooled = okc_pooled_ols(panel)
    okc_fe = okc_panel_fe(panel)
    okc_groups = okc_income_group_analysis(panel)

    # 保存结果
    okc_fe_df = pd.DataFrame([okc_fe])
    okc_fe_df.to_csv(os.path.join(RESULTS, "okc_panel_fe_results.csv"), index=False)

    okc_groups.to_csv(os.path.join(RESULTS, "okc_income_group_2023.csv"))

    print("\n" + "=" * 70)
    print("OKC分析完成")
    print("=" * 70)
    print(f"  结果文件:")
    print(f"    results/panel_master_routeC.csv")
    print(f"    results/okc_pooled_by_year.csv")
    print(f"    results/okc_panel_fe_results.csv")
    print(f"    results/okc_income_group_2023.csv")


if __name__ == "__main__":
    main()
