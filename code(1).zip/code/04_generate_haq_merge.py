"""
生成 haq_merge.csv（05/07 脚本的前置中间文件）。

haq_merge.csv 结构：iso3, haq_2019, nurse_per10k, daly_rate_end
- haq_2019       : GBD 2019 HAQ 指数（2019年、Overall、年龄标准化）
- nurse_per10k   : 最新年纯护士密度（每万人口）
- daly_rate_end  : 2023 年高BMI归因年龄标化 DALY 率（每10万人口）

注意：haq_2019 是 16/18 脚本实际使用的关键列；nurse_per10k 与 daly_rate_end
为 16 脚本早期版本遗留的冗余列，此处一并补全以保持列结构一致。
"""

import os
import sys
import warnings
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from importlib import import_module
loc_map_mod = import_module("02_location_id_map")
LOC_ID_TO_ISO3 = (loc_map_mod.LOC_ID_ID_TO_ISO3
                  if hasattr(loc_map_mod, "LOC_ID_ID_TO_ISO3")
                  else loc_map_mod.LOC_ID_TO_ISO3)

PARENT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GBD_DIR = os.path.join(PARENT, "GBD")
RESULTS = os.path.join(PARENT, "results")

HAQ_CSV = os.path.join(GBD_DIR, "IHME_GBD_2019_HAQ_1990_2019_DATA_Y2022M012D21.CSV")
PANEL_CSV = os.path.join(RESULTS, "panel_master_routeC.csv")
NURSE_PURE_CSV = os.path.join(RESULTS, "nurse_density_pure.csv")


def build_haq_2019():
    """从 GBD HAQ 原始 CSV 提取 2019 年 Overall、年龄标准化 HAQ → iso3"""
    haq = pd.read_csv(HAQ_CSV)
    haq = haq[
        (haq["year_id"] == 2019)
        & (haq["haq_index_age_type"] == "Overall")
        & (haq["age_group_name"] == "Age-standardized")
    ].copy()
    haq["iso3"] = haq["location_id"].map(LOC_ID_TO_ISO3)
    haq = haq.dropna(subset=["iso3"])
    haq = haq[["iso3", "val"]].rename(columns={"val": "haq_2019"})
    # 同一 iso3 可能有多行（不应发生），取第一条
    haq = haq.drop_duplicates(subset=["iso3"], keep="first")
    print(f"  HAQ 2019: {len(haq)} 国")
    return haq


def build_nurse_per10k():
    nurse = pd.read_csv(NURSE_PURE_CSV)
    nurse = nurse[["iso3", "nurse_per10k"]].drop_duplicates(subset=["iso3"])
    print(f"  护理密度: {len(nurse)} 国")
    return nurse


def build_daly_rate_end():
    """从 panel_master_routeC.csv 取 2023 年 DALY 率（末期）"""
    panel = pd.read_csv(PANEL_CSV)
    daly = panel[panel["year"] == 2023][["iso3", "bmi_daly_rate"]].copy()
    daly = daly.rename(columns={"bmi_daly_rate": "daly_rate_end"})
    daly = daly.drop_duplicates(subset=["iso3"])
    print(f"  DALY 2023: {len(daly)} 国")
    return daly


def main():
    haq = build_haq_2019()
    nurse = build_nurse_per10k()
    daly = build_daly_rate_end()

    merged = haq.merge(nurse, on="iso3", how="left")
    merged = merged.merge(daly, on="iso3", how="left")
    merged = merged[["iso3", "haq_2019", "nurse_per10k", "daly_rate_end"]]
    merged = merged.sort_values("iso3")

    out = os.path.join(RESULTS, "haq_merge.csv")
    merged.to_csv(out, index=False)
    print(f"\n已生成 {out}（{len(merged)} 国）")
    print(merged.head(3).to_string(index=False))


if __name__ == "__main__":
    main()
