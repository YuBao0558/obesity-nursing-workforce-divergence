"""
路线C - 多投入多产出面板DEA + Malmquist指数 + Simar-Wilson二阶段回归
================================================================
投入: 护理密度 + 医生密度 + 床位密度 (3投入)
产出: HAQ + UHC指数 (2产出)

分析内容:
1. 多投入多产出BCC-DEA (产出导向, 可变规模报酬)
2. Malmquist指数 (效率的时间变化, 用2010/2020/2023三个时间点)
3. Simar-Wilson二阶段bootstrap回归 (检验GDP/城市化率对效率的影响)
4. 与单投入DEA对比 (验证多投入模型的增量价值)
"""
import os
import sys
import warnings
import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import linprog
import statsmodels.api as sm
from statsmodels.regression.linear_model import OLS

warnings.filterwarnings("ignore")

PARENT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESULTS = os.path.join(PARENT, "results")
os.makedirs(RESULTS, exist_ok=True)


# ============================================================
# 多投入多产出BCC-DEA (产出导向, 可变规模报酬)
# ============================================================

def bcc_dea_output_multi(inputs, outputs):
    """产出导向BCC-DEA (可变规模报酬)
    多投入多产出版本

    对每个DMU j0:
    max φ
    s.t. φ·y_{r0} - Σ_j λ_j·y_{rj} ≤ 0  (对每个产出r)
         Σ_j λ_j·x_{ij} ≤ x_{i,j0}      (对每个投入i)
         Σ_j λ_j = 1                      (凸性约束, BCC)
         λ_j ≥ 0, φ ≥ 0

    效率 = 1/φ (产出导向, φ≥1, 效率≤1)
    或效率 = φ (得分≥1, 越高越无效)

    这里返回φ (效率得分, ≥1, 越高表示同样投入产出越低)
    """
    n = inputs.shape[0]  # DMU数
    m = inputs.shape[1]  # 投入数
    s = outputs.shape[1]  # 产出数

    efficiencies = np.full(n, np.nan)
    lambdas_all = np.full((n, n), np.nan)

    for j0 in range(n):
        # 变量: [φ, λ_1, ..., λ_n]
        n_var = 1 + n
        c = np.zeros(n_var)
        c[0] = -1.0  # max φ → min -φ

        # 不等式约束 A_ub z <= b_ub
        Aub = []
        bub = []

        # 产出约束 (s行): φ·y_{r0} - Σ λ_j·y_{rj} ≤ 0
        for r in range(s):
            row = np.zeros(n_var)
            row[0] = outputs[j0, r]  # φ的系数 = y_{r0}
            row[1:] = -outputs[:, r]  # λ_j的系数 = -y_{rj}
            Aub.append(row)
            bub.append(0.0)

        # 投入约束 (m行): Σ λ_j·x_{ij} ≤ x_{i,j0}
        for i in range(m):
            row = np.zeros(n_var)
            row[0] = 0.0  # φ不出现
            row[1:] = inputs[:, i]
            Aub.append(row)
            bub.append(inputs[j0, i])

        # 等式约束 (1行): Σ λ_j = 1 (BCC凸性)
        Aeq = np.zeros((1, n_var))
        Aeq[0, 1:] = 1.0
        beq = np.array([1.0])

        bounds = [(0, None)] * n_var  # φ≥0, λ_j≥0

        try:
            res = linprog(c, A_ub=np.array(Aub), b_ub=np.array(bub),
                          A_eq=Aeq, b_eq=beq, bounds=bounds, method="highs")
            if res.success:
                efficiencies[j0] = res.x[0]  # φ值 (≥1, 越高越无效)
                lambdas_all[j0] = res.x[1:]
        except Exception:
            pass

    return efficiencies, lambdas_all


def run_multi_dea(panel, year):
    """对指定年份运行多投入多产出DEA"""
    sub = panel[panel["year"] == year].dropna(
        subset=["nurse_per10k", "doc_per10k", "bed_per10k", "haq_2019", "uhc_index"]
    ).copy()
    # 剔除0或负值
    for col in ["nurse_per10k", "doc_per10k", "bed_per10k", "haq_2019", "uhc_index"]:
        sub = sub[sub[col] > 0]

    if len(sub) < 10:
        return None, None, None

    inputs = sub[["nurse_per10k", "doc_per10k", "bed_per10k"]].values
    outputs = sub[["haq_2019", "uhc_index"]].values

    # 注意: HAQ是2019固定值, 对所有年份相同
    # UHC是各年值

    eff, lambdas = bcc_dea_output_multi(inputs, outputs)
    sub = sub.copy()
    sub["efficiency_phi"] = eff  # φ值 (≥1, 越高越无效)
    sub["efficiency_score"] = 1.0 / eff  # 效率得分 (≤1, 越高越好)

    return sub, eff, lambdas


def run_single_dea_comparison(panel, year):
    """单投入DEA对比 (护理→HAQ)"""
    sub = panel[panel["year"] == year].dropna(
        subset=["nurse_per10k", "haq_2019"]
    ).copy()
    sub = sub[(sub["nurse_per10k"] > 0) & (sub["haq_2019"] > 0)]

    if len(sub) < 10:
        return None

    inputs = sub[["nurse_per10k"]].values
    outputs = sub[["haq_2019"]].values

    eff, _ = bcc_dea_output_multi(inputs, outputs)
    sub = sub.copy()
    sub["efficiency_phi_single"] = eff
    return sub


# ============================================================
# Malmquist指数
# ============================================================

def compute_malmquist(panel, year_t, year_t1):
    """计算两期之间的Malmquist指数

    Malmquist = EC × TC
    EC = 效率变化 (catch-up)
    TC = 技术变化 (frontier shift)

    用交叉效率计算:
    EC = [D_t(x_t1,y_t1)/D_t(x_t,y_t)]
    TC = sqrt([D_t(x_t,y_t)/D_t1(x_t,y_t)] × [D_t(x_t1,y_t1)/D_t1(x_t1,y_t1)])
    """
    sub_t = panel[panel["year"] == year_t].dropna(
        subset=["nurse_per10k", "doc_per10k", "bed_per10k", "haq_2019", "uhc_index"]
    ).copy()
    sub_t1 = panel[panel["year"] == year_t1].dropna(
        subset=["nurse_per10k", "doc_per10k", "bed_per10k", "haq_2019", "uhc_index"]
    ).copy()

    for col in ["nurse_per10k", "doc_per10k", "bed_per10k", "haq_2019", "uhc_index"]:
        sub_t = sub_t[sub_t[col] > 0]
        sub_t1 = sub_t1[sub_t1[col] > 0]

    # 取交集国家
    common = set(sub_t["iso3"]) & set(sub_t1["iso3"])
    sub_t = sub_t[sub_t["iso3"].isin(common)].sort_values("iso3").reset_index(drop=True)
    sub_t1 = sub_t1[sub_t1["iso3"].isin(common)].sort_values("iso3").reset_index(drop=True)

    if len(sub_t) < 10:
        return None

    inputs_t = sub_t[["nurse_per10k", "doc_per10k", "bed_per10k"]].values
    outputs_t = sub_t[["haq_2019", "uhc_index"]].values
    inputs_t1 = sub_t1[["nurse_per10k", "doc_per10k", "bed_per10k"]].values
    outputs_t1 = sub_t1[["haq_2019", "uhc_index"]].values

    n = len(sub_t)

    # 1. 同期效率
    eff_t_t, _ = bcc_dea_output_multi(inputs_t, outputs_t)      # D_t(x_t,y_t)
    eff_t1_t1, _ = bcc_dea_output_multi(inputs_t1, outputs_t1)  # D_t1(x_t1,y_t1)

    # 2. 交叉效率 (用t期前沿评价t1期DMU, 和用t1期前沿评价t期DMU)
    # 需要修改DEA函数: 用参考集的前沿评价目标DMU
    def cross_eff(inputs_ref, outputs_ref, inputs_target, outputs_target):
        """用参考集构建前沿, 评价目标DMU"""
        n_ref = inputs_ref.shape[0]
        n_target = inputs_target.shape[0]
        m = inputs_ref.shape[1]
        s = outputs_ref.shape[1]
        effs = np.full(n_target, np.nan)

        for j0 in range(n_target):
            n_var = 1 + n_ref
            c = np.zeros(n_var)
            c[0] = -1.0

            Aub = []
            bub = []
            # 产出约束
            for r in range(s):
                row = np.zeros(n_var)
                row[0] = outputs_target[j0, r]
                row[1:] = -outputs_ref[:, r]
                Aub.append(row)
                bub.append(0.0)
            # 投入约束
            for i in range(m):
                row = np.zeros(n_var)
                row[1:] = inputs_ref[:, i]
                Aub.append(row)
                bub.append(inputs_target[j0, i])
            # 凸性
            Aeq = np.zeros((1, n_var))
            Aeq[0, 1:] = 1.0
            beq = np.array([1.0])
            bounds = [(0, None)] * n_var

            try:
                res = linprog(c, A_ub=np.array(Aub), b_ub=np.array(bub),
                              A_eq=Aeq, b_eq=beq, bounds=bounds, method="highs")
                if res.success:
                    effs[j0] = res.x[0]
            except:
                pass
        return effs

    # D_t(x_t1, y_t1): 用t期前沿评价t1期
    eff_t_t1 = cross_eff(inputs_t, outputs_t, inputs_t1, outputs_t1)
    # D_t1(x_t, y_t): 用t1期前沿评价t期
    eff_t1_t = cross_eff(inputs_t1, outputs_t1, inputs_t, outputs_t)

    # Malmquist分解
    # EC = eff_t_t1 / eff_t_t  (catch-up)
    # TC = sqrt(eff_t_t/eff_t1_t × eff_t_t1/eff_t1_t1)  (frontier shift)
    # M = EC × TC

    ec = eff_t_t1 / np.where(eff_t_t > 0, eff_t_t, np.nan)
    tc = np.sqrt((eff_t_t / np.where(eff_t1_t > 0, eff_t1_t, np.nan)) *
                 (eff_t_t1 / np.where(eff_t1_t1 > 0, eff_t1_t1, np.nan)))
    malmquist = ec * tc

    result = sub_t[["iso3", "country_name"]].copy()
    result["eff_t"] = eff_t_t
    result["eff_t1"] = eff_t1_t1
    result["eff_cross_t_t1"] = eff_t_t1
    result["eff_cross_t1_t"] = eff_t1_t
    result["ec"] = ec
    result["tc"] = tc
    result["malmquist"] = malmquist
    result["year_t"] = year_t
    result["year_t1"] = year_t1

    return result


# ============================================================
# Simar-Wilson二阶段回归
# ============================================================

def simar_wilson_second_stage(panel, year, n_bootstrap=2000):
    """Simar-Wilson二阶段bootstrap回归

    第一阶段: DEA效率得分
    第二阶段: 效率 ~ GDP + 城市化率 + 收入分组 (bootstrap截断回归)
    """
    sub = panel[panel["year"] == year].dropna(
        subset=["nurse_per10k", "doc_per10k", "bed_per10k", "haq_2019", "uhc_index",
                "gni_pc", "urban_pct"]
    ).copy()

    for col in ["nurse_per10k", "doc_per10k", "bed_per10k", "haq_2019", "uhc_index", "gni_pc"]:
        sub = sub[sub[col] > 0]

    if len(sub) < 20:
        return None

    # 第一阶段: DEA
    inputs = sub[["nurse_per10k", "doc_per10k", "bed_per10k"]].values
    outputs = sub[["haq_2019", "uhc_index"]].values
    eff, _ = bcc_dea_output_multi(inputs, outputs)
    sub["efficiency_phi"] = eff

    # 第二阶段: 回归 -ln(efficiency) ~ ln(GDP) + 城市化率
    # 用 -ln(φ) 作为因变量 (因为φ≥1, -ln(φ)≤0, 表示效率损失)
    sub["ln_eff"] = -np.log(sub["efficiency_phi"].clip(lower=1.0))
    sub["ln_gdp"] = np.log(sub["gni_pc"])

    X = sm.add_constant(sub[["ln_gdp", "urban_pct"]])
    y = sub["ln_eff"]

    # OLS基准
    model_ols = OLS(y, X).fit()

    # Bootstrap
    betas_boot = np.zeros((n_bootstrap, 3))
    residuals = y - model_ols.predict(X)
    sigma = residuals.std()

    np.random.seed(42)
    for b in range(n_bootstrap):
        # 生成bootstrap样本: y* = Xβ + ε*, ε* ~ N(0, σ²) 截断
        y_star = model_ols.predict(X) + np.random.normal(0, sigma, len(y))
        # 截断: y* ≤ 0
        y_star = np.minimum(y_star, 0)
        try:
            m = OLS(y_star, X).fit()
            betas_boot[b] = m.params
        except:
            betas_boot[b] = np.nan

    # Bootstrap标准误和置信区间
    se_boot = np.nanstd(betas_boot, axis=0)
    ci_lower = np.nanpercentile(betas_boot, 2.5, axis=0)
    ci_upper = np.nanpercentile(betas_boot, 97.5, axis=0)

    return {
        "year": year,
        "n": len(sub),
        "beta_const": model_ols.params["const"],
        "beta_ln_gdp": model_ols.params["ln_gdp"],
        "beta_urban": model_ols.params["urban_pct"],
        "se_const": se_boot[0],
        "se_ln_gdp": se_boot[1],
        "se_urban": se_boot[2],
        "ci_ln_gdp": [ci_lower[1], ci_upper[1]],
        "ci_urban": [ci_lower[2], ci_upper[2]],
        "r2": model_ols.rsquared,
    }


# ============================================================
# 主流程
# ============================================================

def main():
    print("=" * 70)
    print("路线C - 多投入多产出面板DEA + Malmquist + Simar-Wilson")
    print("=" * 70)

    panel = pd.read_csv(os.path.join(RESULTS, "panel_master_routeC.csv"))
    print(f"面板数据: {len(panel)} 行, {panel['iso3'].nunique()} 国")

    # ===== 1. 多投入DEA (各年横截面) =====
    print("\n" + "=" * 70)
    print("[1] 多投入多产出DEA (护理+医生+床位 → HAQ+UHC)")
    print("=" * 70)

    dea_results = []
    for year in [2010, 2020, 2023]:
        result, eff, lambdas = run_multi_dea(panel, year)
        if result is not None:
            result["analysis_year"] = year
            dea_results.append(result)
            # 效率与收入的关系
            sub_clean = result.dropna(subset=["efficiency_phi", "gni_pc"])
            if len(sub_clean) > 5:
                rho, p = stats.spearmanr(sub_clean["efficiency_phi"], sub_clean["gni_pc"])
                print(f"  {year}: n={len(result)}, 效率φ中位={np.nanmedian(eff):.3f}, "
                      f"Spearman ρ(GNI)={rho:.3f} (p={p:.4f})")

    if dea_results:
        dea_all = pd.concat(dea_results, ignore_index=True)
        dea_all.to_csv(os.path.join(RESULTS, "dea_multi_input_results.csv"), index=False)
        print(f"\n  多投入DEA结果已保存: results/dea_multi_input_results.csv ({len(dea_all)} 行)")

    # ===== 2. 单投入DEA对比 =====
    print("\n" + "=" * 70)
    print("[2] 单投入DEA对比 (护理→HAQ)")
    print("=" * 70)

    for year in [2010, 2020, 2023]:
        single = run_single_dea_comparison(panel, year)
        if single is not None:
            sub_clean = single.dropna(subset=["efficiency_phi_single", "gni_pc"])
            if len(sub_clean) > 5:
                rho_s, p_s = stats.spearmanr(sub_clean["efficiency_phi_single"], sub_clean["gni_pc"])
                print(f"  {year}: n={len(single)}, φ中位={np.nanmedian(single['efficiency_phi_single']):.3f}, "
                      f"Spearman ρ(GNI)={rho_s:.3f} (p={p_s:.4f})")

    # ===== 3. Malmquist指数 =====
    print("\n" + "=" * 70)
    print("[3] Malmquist指数 (效率变化 × 技术变化)")
    print("=" * 70)

    malm_results = []
    for (y_t, y_t1) in [(2010, 2020), (2020, 2023)]:
        result = compute_malmquist(panel, y_t, y_t1)
        if result is not None:
            result.to_csv(os.path.join(RESULTS, f"malmquist_{y_t}_{y_t1}.csv"), index=False)
            malm_results.append(result)
            valid = result.dropna(subset=["malmquist"])
            print(f"  {y_t}→{y_t1}: n={len(valid)}, "
                  f"Malmquist中位={valid['malmquist'].median():.3f}, "
                  f"EC中位={valid['ec'].median():.3f}, TC中位={valid['tc'].median():.3f}")
            # 方向解读
            m_med = valid["malmquist"].median()
            if m_med > 1:
                print(f"    → Malmquist > 1: 整体效率改善 (前沿追赶+技术进步)")
            else:
                print(f"    → Malmquist < 1: 整体效率退化")

    if malm_results:
        malm_all = pd.concat(malm_results, ignore_index=True)
        malm_all.to_csv(os.path.join(RESULTS, "malmquist_all.csv"), index=False)

    # ===== 4. Simar-Wilson二阶段回归 =====
    print("\n" + "=" * 70)
    print("[4] Simar-Wilson二阶段bootstrap回归")
    print("=" * 70)

    sw_results = []
    for year in [2010, 2020, 2023]:
        result = simar_wilson_second_stage(panel, year, n_bootstrap=1000)
        if result:
            sw_results.append(result)
            print(f"  {year}: n={result['n']}, R²={result['r2']:.3f}")
            print(f"    β(ln GDP) = {result['beta_ln_gdp']:>8.4f} (SE={result['se_ln_gdp']:.4f}, "
                  f"95% CI [{result['ci_ln_gdp'][0]:.4f}, {result['ci_ln_gdp'][1]:.4f}])")
            print(f"    β(城市化率) = {result['beta_urban']:>8.4f} (SE={result['se_urban']:.4f}, "
                  f"95% CI [{result['ci_urban'][0]:.4f}, {result['ci_urban'][1]:.4f}])")

    if sw_results:
        sw_df = pd.DataFrame(sw_results)
        sw_df.to_csv(os.path.join(RESULTS, "simar_wilson_second_stage.csv"), index=False)
        print(f"\n  Simar-Wilson结果已保存: results/simar_wilson_second_stage.csv")

    # ===== 5. 多投入 vs 单投入对比 =====
    print("\n" + "=" * 70)
    print("[5] 多投入 vs 单投入DEA对比")
    print("=" * 70)

    comparison = []
    for year in [2010, 2020, 2023]:
        multi_result, _, _ = run_multi_dea(panel, year)
        single = run_single_dea_comparison(panel, year)
        if multi_result is not None and single is not None:
            merged = multi_result[["iso3", "efficiency_phi"]].merge(
                single[["iso3", "efficiency_phi_single"]], on="iso3", how="inner"
            )
            merged = merged.dropna()
            if len(merged) > 5:
                rho_m, p_m = stats.spearmanr(merged["efficiency_phi"], merged["gni_pc"] if "gni_pc" in merged else merged["efficiency_phi"])
                rho_compare, _ = stats.spearmanr(merged["efficiency_phi"], merged["efficiency_phi_single"])
                print(f"  {year}: n={len(merged)}, "
                      f"多投入φ中位={merged['efficiency_phi'].median():.3f}, "
                      f"单投入φ中位={merged['efficiency_phi_single'].median():.3f}, "
                      f"二者ρ={rho_compare:.3f}")
                comparison.append({
                    "year": year,
                    "n": len(merged),
                    "multi_median_phi": merged["efficiency_phi"].median(),
                    "single_median_phi": merged["efficiency_phi_single"].median(),
                    "spearman_multi_vs_single": rho_compare,
                })

    if comparison:
        comp_df = pd.DataFrame(comparison)
        comp_df.to_csv(os.path.join(RESULTS, "dea_multi_vs_single_comparison.csv"), index=False)

    print("\n" + "=" * 70)
    print("多投入DEA分析完成")
    print("=" * 70)
    print("  结果文件:")
    print("    results/dea_multi_input_results.csv")
    print("    results/malmquist_all.csv")
    print("    results/simar_wilson_second_stage.csv")
    print("    results/dea_multi_vs_single_comparison.csv")


if __name__ == "__main__":
    main()
